/*******************************************************************************
* Copyright (c) 2014 Giuseppe Galeota. All rights reserved
*
*******************************************************************************/
application {
	name="Pentaho_BA_server"
	
	service {
		name = "pentaho"
	}
}
/*******************************************************************************
* Copyright (c) 2014 Giuseppe Galeota. All rights reserved
*
*******************************************************************************/
import org.cloudifysource.utilitydomain.context.ServiceContextFactory
import org.cloudifysource.dsl.utils.ServiceUtils
import org.hyperic.sigar.OperatingSystem

println "pentaho_install.groovy: Installazione del BA server Pentaho..."

//######################################## Sezione DEFINIZIONE FUNZIONI

//* --------------------------------Definisco la funzione di installazione
def installLinuxBAserverPentaho(config,context,builder,currVendor,installScript) {
    
	println "pentaho_install.groovy: all'interno della funzione installLinuxBAserverPentaho()..."
	println "pentaho_install.groovy: Acquisizione user, pass downloadPath dal file config..."
    def usernamePentaho = "${config.pentahoUser}"
	def passwordPentaho = "${config.pentahoUserPass}"
	def downloadPath = "${config.downloadPath}"
	def zipName = "${config.zipName}"
	
	println "pentaho_install.groovy: user is: ${usernamePentaho}"
	println "pentaho_install.groovy: pass is: ${passwordPentaho}"
	println "pentaho_install.groovy: downloadPath is: ${downloadPath}"
	println "pentaho_install.groovy: zipName is: ${zipName}"
	
	builder.sequential {
	    //context.serviceDirectory  è la directory dove si trova la ricetta del servizio
	    //Faccio  in modo che la directory del servizio sia eseguibile....
		echo(message:"pentaho_install.groovy: Dentro builder. Eseguo Chmodding +x della cartella ${context.serviceDirectory} ...")
		chmod(dir:"${context.serviceDirectory}", perm:"+x", includes:"*.sh")

		echo(message:"pentaho_install.groovy: Eseguo ${context.serviceDirectory}/${installScript} os is ${currVendor}...")
		exec(executable: "${context.serviceDirectory}/${installScript}",failonerror: "true") {
			arg(value:"${usernamePentaho}")		
			arg(value:"${passwordPentaho}")
			arg(value:"${downloadPath}")
			arg(value:"${zipName}")			
		}
	}
}
//---------------------------------- Fine definizione funzione installazione servizio



/* -------------------------------- Ricavo alcuni parametri di configurazione--------------------------------------------------------*/
//config: contiene il file mysql-service.properties
//config.qualcosa è proprio uno degli elementi del file in questione
println "pentaho_install.groovy: acquisizione file di configurazione config..."
config=new ConfigSlurper().parse(new File('pentaho-service.properties').toURL())

//context: raccoglie tutte le informazioni sul servizio in esecuzione
println "pentaho_install.groovy: acquisizione contesto..."
context = ServiceContextFactory.getServiceContext()

// Check sull'indirizzo IP privato della macchina
def pentahoHost

if (  context.isLocalCloud()  ) {
	pentahoHost =InetAddress.getLocalHost().getHostAddress()
}
else {
	pentahoHost =System.getenv()["CLOUDIFY_AGENT_ENV_PRIVATE_IP"]
}

// Stampa a video del valore di alcune variabili (println)
println "pentaho_install.groovy: BAserverPentahoPrivateHost is ${pentahoHost}"
println "pentaho_install.groovy: Pentaho downloadPath is ${config.downloadPath}"
println "pentaho_install.groovy: PentahoUser is ${config.pentahoUser}"
println "pentaho_install.groovy: pentahoUserPass is ${config.pentahoUserPass}"

// Condivisione degli attributi prendendoli dal file di configurazione (context.attributes.thisInstance[]=.....)
context.attributes.thisInstance["BAserverPentahoPrivateHost"] = "${pentahoHost}"
context.attributes.thisInstance["downloadPath"] = "${config.downloadPath}"
context.attributes.thisInstance["pentahoUser"] = "${config.pentahoUser}"
context.attributes.thisInstance["pentahoUserPass"] = "${config.pentahoUserPass}"

println "pentaho_install.groovy: Costruzione Builder"
builder = new AntBuilder()

//os conterrà una istanza della classe OperatingSystem
def os = OperatingSystem.getInstance()
//chiamo il metodo getVendor dell'oggetto OperatingSystem
// currVendor restituisce il tipo di sistema operativo
def currVendor=os.getVendor()
println "pentaho_install.groovy: Vendor del sistema operativo e': ${currVendor}"


switch (currVendor) {
		case ["Ubuntu", "Debian", "Mint"]:		
			context.attributes.thisInstance["binFolder"]="/usr/bin"
			installLinuxBAserverPentaho(config,context,builder,currVendor,"installOnUbuntu.sh")
			break
		case ["Red Hat", "CentOS", "Fedora", "Amazon",""]:	
			println "pentaho_install.groovy: Vendor del sistema operativo ${currVendor} non implementato"
			break					
		case ~/.*(?i)(Microsoft|Windows).*/:
			println "pentaho_install.groovy: Vendor del sistema operativo ${currVendor} non implementato"
			break
		default: throw new Exception("Support for ${currVendor} is not implemented")
}

println "pentaho_install.groovy: End"	
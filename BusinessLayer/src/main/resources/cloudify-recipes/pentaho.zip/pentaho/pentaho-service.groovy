/*******************************************************************************
* Copyright (c) 2014 Giuseppe Galeota. All rights reserved
*
***********************************************/
import java.util.concurrent.TimeUnit;
//import static JmxMonitors.*

service {
	name "pentaho"
	
	icon "pentaho.gif"
	type "APP_SERVER"
	
    elastic true
	numInstances 1
	minAllowedInstances 1
	maxAllowedInstances 2
	
	compute {
		template "SMALL_LINUX"
	}

	lifecycle {
		
		//E' una probe
		details {
			def currPublicIP =context.getPublicAddress()	
					//restituisce una Map di coppie chiave:valore.
					return ["BAserver IP":currPublicIP,"BAserver Port":BAserverPort]
		}

		//init    "pentaho_init.groovy"
		install "pentaho_install.groovy"
		//start   "pentaho_start.groovy"		
		
		//startDetectionTimeoutSecs 240
		//startDetection {
		//	println "pentaho-service.groovy(startDetection): arePortsFree http=${BAserverPort} ..."
		//	!ServiceUtils.arePortsFree([BAserverPort])
		//}
		
		//preStop "pentaho_stop.groovy"		
		
	}
/*
	userInterface {
		
		widgetGroups = ([
			widgetGroup {
				name "Process Cpu Usage"
				widgets ([
					balanceGauge{metric = "Process Cpu Usage"},
					barLineChart{
						metric "Process Cpu Usage"
						axisYUnit Unit.PERCENTAGE
					}
				])
			} ,
			widgetGroup {
				name "Total Process Virtual Memory"
				widgets([
					balanceGauge{metric = "Total Process Virtual Memory"},
					barLineChart {
						metric "Total Process Virtual Memory"
						axisYUnit Unit.MEMORY
					}
				])
			} ,
			widgetGroup {
				name "Num Of Active Threads"
				widgets ([
					balanceGauge{metric = "Num Of Active Threads"},
					barLineChart{
						metric "Num Of Active Threads"
						axisYUnit Unit.REGULAR
					}
				])
			} ,
			widgetGroup {
				name "Current Http Threads Busy"
				widgets([
					balanceGauge{metric = "Current Http Threads Busy"},
					barLineChart {
						metric "Current Http Threads Busy"
						axisYUnit Unit.REGULAR
					}
				])
			} ,
			widgetGroup {
				name "Current Http Thread Count"
				widgets([
					balanceGauge{metric = "Current Http Thread Count"},
					barLineChart {
						metric "Current Http Thread Count"
						axisYUnit Unit.REGULAR
					}
				])
			} ,
			widgetGroup {
				name "Request Backlog"
				widgets([
					balanceGauge{metric = "Backlog"},
					barLineChart {
						metric "Backlog"
						axisYUnit Unit.REGULAR
					}
				])
			} ,
			widgetGroup {
				name "Active Sessions"
				widgets([
					balanceGauge{metric = "Active Sessions"},
					barLineChart {
						metric "Active Sessions"
						axisYUnit Unit.REGULAR
					}
				])
			} ,
			widgetGroup {
				name "Total Requests Count"
				widgets([
					balanceGauge{metric = "Total Requests Count"},
					barLineChart {
						metric "Total Requests Count"
						axisYUnit Unit.REGULAR
					}
				])
			} ,
			widgetGroup {
				name "Total Process Cpu Time"
				widgets([
					balanceGauge{metric = "Total Process Cpu Time"},
					barLineChart {
						metric "Total Process Cpu Time"
						axisYUnit Unit.REGULAR
					}
				])
			}
		])
	}
	*/
}
#!/bin/bash -x

# args:
# $1 user name dell'utente Pentaho
# $2 password dell'utente Pentaho
# $3 download Path di BA server Pentaho
# $4 zip name


# argomenti inseriti nella chiamata al file installOnUbuntu.sh  
usernamePentaho=$1
passwordPentaho=$2
downloadPathPentaho=$3
zipName=$4
echo "Argomenti passati alla chiamata: $usernamePentaho $passwordPentaho $downloadPathPentaho $zipName"

# Funzione errore di uscita
# args:
# $1 the error code of the last command (should be explicitly passed)
# $2 the message to print in case of an error
# 
# an error message is printed and the script exits with the provided error code
function funzione_errore_uscita {
	echo "$2 : error code: $1"
	exit ${1}
}

# Doppio pipe || = if the first command succeed the second will never be executed ovvero se export fallisce verrà chiamata "funzione_errore_uscita arg_1 arg_2"
export PATH=$PATH:/usr/sbin:/sbin:/usr/bin || funzione_errore_uscita $? "Failed on: export PATH=$PATH:/usr/sbin:/sbin"

# check chi sono
echo "Determino chi sono..."

if [ `whoami` = "root" ] 
			then
				echo "Sono gia root..."
			else
				echo "Non sono un utente root..." 
				su root || funzione_errore_uscita $? "Fallito su: su root"
				
fi

# Check sy requiretty
echo "Check su requiretty..."
if sudo grep -q -E '[^!]requiretty' /etc/sudoers; then
    echo "Defaults:`whoami` !requiretty" | sudo tee /etc/sudoers.d/`whoami` >/dev/null
    sudo chmod 0440 /etc/sudoers.d/`whoami`
fi

# The existence of the usingAptGet file in the ext folder will later serve as a flag that "we" are on Ubuntu or Debian or Mint
echo "Using apt-get. Updating apt-get on one of the following : Ubuntu, Debian, Mint" > usingAptGet
sudo apt-get -y -q update || funzione_errore_uscita $? "Failed on: sudo apt-get -y update"

# Creo utente pentaho e modifico la sua password
echo "Creo utente pentaho e modifico la sua password"
sudo useradd -s /bin/bash -m $usernamePentaho || funzione_errore_uscita $? "Fallito su: sudo useradd -s /bin/bash -m pentaho"

sudo passwd $usernamePentaho <<_EOF_
$passwordPentaho
$passwordPentaho
_EOF_

# Assegno all’utente pentaho i privilegi di sudo nel file /etc/sudoers:
echo "# Asegno all utente pentaho i privilegi di sudo" | sudo tee -a /etc/sudoers
eval stringa1='ALL=\(ALL\)'
eval stringa2=ALL
echo "$usernamePentaho $stringa1 $stringa2" | sudo tee -a /etc/sudoers

# creo directory pentaho
echo "Creo directory pentaho..."
echo whoami
echo $HOME
echo ""
#login <<_EOF_
#$usernamePentaho
#$passwordPentaho
#_EOF_
#echo "Eseguito login $usernamePentaho"
su $usernamePentaho || funzione_errore_uscita $? "su $usernamePentaho"
echo whoami
echo $HOME
echo ""
cd /home/$usernamePentaho || funzione_errore_uscita $? "Fallito su: cd /home/$usernamePentaho"
echo "Eseguito cd /home/$usernamePentaho"
mkdir $usernamePentaho || funzione_errore_uscita $? "Fallito su: mkdir –p $usernamePentaho"
cd $usernamePentaho || funzione_errore_uscita $? "Fallito su: cd $usernamePentaho"
mkdir server || funzione_errore_uscita $? "Fallito su: mkdir server"
echo "Eseguito cd /home/$usernamePentaho"
chmod 777 /home/$usernamePentaho/$usernamePentaho || funzione_errore_uscita $? "Fallito su: chmod 777 /home/$usernamePentaho/$usernamePentaho "
chmod 777 /home/$usernamePentaho/$usernamePentaho/server || funzione_errore_uscita $? "Fallito su: chmod 777 /home/$usernamePentaho/$usernamePentaho/server"

# Installo openJDK
echo "installo open JDK 7 usando apt-get install...." 
echo "Precedente valore della variabile JAVA_HOME: $JAVA_HOME"
whoami
echo "Divento root..."
sudo su || funzione_errore_uscita $? "Fallito su: sudo su"
sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y install openjdk-7-jdk || funzione_errore_uscita $? "Errore nella installazione di: sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -q  openjdk-7-jdk ... "
echo java -version
echo Nuovo valore della variabile JAVA_HOME: $JAVA_HOME
# Il risultato di JAVA_HOME e': /root/java  ed e' questa la variabile che pentaho usa. Peccato che quel JAVA sia la 1.6 installata da cloudify, mentre pentaho vuole la 1.7!!!
# Tuttavia, il tutto sembra funzionare
#Installo unzip
echo "installo unzip..." 
sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y install unzip || funzione_errore_uscita $? "Errore nella installazione di: sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -q  unzip ... "


# Installo BAserver
echo "Installo il BA server"
su $usernamePentaho || funzione_errore_uscita $? "Fallito su: su pentaho"
cd /home/$usernamePentaho/$usernamePentaho/server
wget $downloadPathPentaho
unzip $zipName

# Abilito i driver JDBC
chmod 777 /home/$usernamePentaho/$usernamePentaho/server/biserver-ce/tomcat/lib/* || funzione_errore_uscita $? "Fallito su: chmod 777 /home/pentaho/pentaho/server/biserver-ce/tomcat/lib/*"

echo "Starting BA server"
cd /home/$usernamePentaho/$usernamePentaho/server/biserver-ce/ || funzione_errore_uscita $? "Fallito su: cd /home/$usernamePentaho/$usernamePentaho/server/biserver-ce/"
./start-pentaho.sh || funzione_errore_uscita $? "Fallito su: ./start-pentaho.sh"

echo "installOnUbuntu.sh: End"
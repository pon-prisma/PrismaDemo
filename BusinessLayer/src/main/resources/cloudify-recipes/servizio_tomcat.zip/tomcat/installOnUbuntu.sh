#!/bin/bash -x

# argomenti inseriti nella chiamata al file installOnUbuntu.sh 

echo "+++++++++++++++++++++++++++++++++++++++++++"
echo "+++++++++++++++++ Dentro InstallOnUbuntu.sh" 


serviceDirectory=$1
unzipDir=$2

downloadPath=$3
servicePackName=$4

sourcePath=$5
warName=$6

catalinaHome=$7			
contextPath=$8

port=$9
ajpPort=${10}
shutdownPort=${11}

mysqlJDBC=${12}
postgresJDBC=${13}

userTomcat=${14}
passTomcat=${15}

sourceName=${16}


# Funzione errore di uscita
# args:
# $1 the error code of the last command (should be explicitly passed)
# $2 the message to print in case of an error
# 
# an error message is printed and the script exits with the provided error code
function funzione_errore_uscita {
	echo "$2 : error code: $1"
	exit ${1}
}

# Doppio pipe || = if the first command succeed the second will never be executed ovvero se export fallisce verrà chiamata "funzione_errore_uscita arg_1 arg_2"
export PATH=$PATH:/usr/sbin:/sbin:/usr/bin || funzione_errore_uscita $? "Failed on: export PATH=$PATH:/usr/sbin:/sbin"

# Check sy requiretty
echo "Check su requiretty..."
if sudo grep -q -E '[^!]requiretty' /etc/sudoers; then
    echo "Defaults:`whoami` !requiretty" | sudo tee /etc/sudoers.d/`whoami` >/dev/null
    sudo chmod 0440 /etc/sudoers.d/`whoami`
fi

# The existence of the usingAptGet file in the ext folder will later serve as a flag that "we" are on Ubuntu or Debian or Mint
#echo "Using apt-get. Updating apt-get on one of the following : Ubuntu, Debian, Mint" > usingAptGet
#sudo apt-get -y -q update || funzione_errore_uscita $? "Failed on: sudo apt-get -y update"

echo "################################################"
echo "----------------Installazione JAVA 7 Oracle...." 

sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y purge openjdk* || funzione_errore_uscita $? "Failed on: purge openjdk*"
sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y install python-software-properties || funzione_errore_uscita $? "Failed on: install python-software-properties "
sudo add-apt-repository -y ppa:webupd8team/java || funzione_errore_uscita $? "Failed on: add-apt-repository ppa:webupd8team/java"
sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y update || funzione_errore_uscita $? "Failed on: apt-get update*"
echo debconf shared/accepted-oracle-license-v1-1 select true | sudo debconf-set-selections
echo debconf shared/accepted-oracle-license-v1-1 seen true | sudo debconf-set-selections
sudo apt-get -y install oracle-java7-installer || funzione_errore_uscita $? "Failed on: apt-get install oracle-java7-installer"

echo "-------------------Installazione java completata"
echo "################################################"


# Ora sto nella "context.serviceDirectory dove ci sono i file di tomcat.groovy"
echo "################################################"
echo "-----------------Installazione tomcat"
cd ${unzipDir} || funzione_errore_uscita $? "Failed on: cd ${unzipDir}"
wget $downloadPath || funzione_errore_uscita $? "Failed on: wget $downloadPath"
sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y install unzip
unzip $servicePackName.zip || funzione_errore_uscita $? "Failed on: unzip"
mv $servicePackName $serviceDirectory || funzione_errore_uscita $? "Failed on: move"
chmod 777 ${catalinaHome}/bin/*.sh
# Ricordo che catalinaHome = ${context.serviceDirectory}/${config.servicePackName}

# Ritorno nella serviceDirectory e copio i connettori JDBC in ${catalinaHome}/lib, supponendo che nella serviceDirectory i
# soli file .jar siano quelli dei driver...
echo "------------------Download JDBC driver"
cd ${catalinaHome}/lib
wget $mysqlJDBC || funzione_errore_uscita $? "Failed on: wget $mysqlJDBC"
wget $postgresJDBC || funzione_errore_uscita $? "Failed on: wget $postgresJDBC"
echo "-----------------------Fine installazione tomcat"
echo "################################################"

echo "###########################################"
echo "-----------------Installazione sorgente.war"
cd $serviceDirectory

echo "Verifico se il sorgente si trova sul repository oppure nella directory Cloudify di tomcat..."
if [[ $sourcePath == *http* ]]; then
  echo "sourcePath = $sourcePath"
  echo "sourcePath contiene http: download war da repository...."
  # wget -O $warName $sourcePath
  wget --retry-connrefused --waitretry=1 --read-timeout=20 --timeout=15 -t 0 -O $warName $sourcePath
  # warName=ROOT.war
  cp $warName ${catalinaHome}/webapps  || funzione_errore_uscita $? "Failed on: copy $warName"

else
	echo "sourcePath = $sourcePath"
	echo "sourcePath NON contiene http: Verifico che il war si trovi nella  ServiceDirectory..."

	if [  -a $serviceDirectory/$sourcePath ]; then
		echo "Il file $sourcePath esiste nella ServiceDirectory $serviceDirectory: coping into ${catalinaHome}/webapps"
    mv $sourcePath ${catalinaHome}/webapps/$warName
    #cp $warName ${catalinaHome}/webapps

    else
     	echo "ERRORE - Il file $warName non esiste nella ServiceDirectory $serviceDirectory"
    fi
    
fi

echo "Faccio in modo che l'applicazione sia raggiungibile al root path..."
#mv ${catalinaHome}/webapps/$warName ${catalinaHome}/webapps/ROOT.war
mv ${catalinaHome}/webapps/ROOT ${catalinaHome}/webapps/HOME

echo "------------Fine installazione sorgente.war"
echo "###########################################"


echo "###########################################"
echo "-----------------Configurazione tomcat ...."

echo "-----Configurazione utenti di management /conf/tomcat-users.xml"
sed -i -e '/<tomcat-users>/a <role rolename="manager-gui"/> \n <role rolename="admin-gui"/> \n <user name="'${userTomcat}'"   password="'${passTomcat}'" roles="admin-gui, manager-gui, manager-script, admin-script" />' ${catalinaHome}/conf/tomcat-users.xml

echo "-----Personalizzo conf/server.xml per le porte di ascolto"
sed -i -e "s/port=\"8080\"/port=\"${port}\"/" ${catalinaHome}/conf/server.xml
sed -i -e "s/port=\"8009\"/port=\"${ajpPort}\"/" ${catalinaHome}/conf/server.xml
sed -i -e "s/port=\"8005\"/port=\"${shutdownPort}\"/" ${catalinaHome}/conf/server.xml
sed -i -e "s/<Engine name=\"Catalina\" defaultHost=\"localhost\">/<Engine name=\"Catalina\" defaultHost=\"localhost\" jvmRoute=\"tomcat\">/" ${catalinaHome}/conf/server.xml

echo "-----Personalizzo catalina.sh"
sed -i -e '99i JAVA_OPTS="-XX:MaxPermSize=160M -XX:NewSize=256M -Xms512M"\nJAVA_OPTS="$JAVA_OPTS -Xmx2048M -Xss512K"' ${catalinaHome}/bin/catalina.sh

echo "----Personalizzo catalina.sh per JAVA_HOME e CATALINA_HOME"
sed -i -e '/JAVA_OPTS="$JAVA_OPTS /a JAVA_HOME="/usr/lib/jvm/java-7-oracle"' ${catalinaHome}/bin/catalina.sh
sed -i -e '/JAVA_OPTS=\"$JAVA_OPTS /a 'CATALINA_HOME="${catalinaHome}"'' ${catalinaHome}/bin/catalina.sh

echo "-----------------Fine Configurazione tomcat"
echo "###########################################"


#echo "-----Faccio in modo che il contextPath sia quello di ROOT"
#sed -i -e "s/<\/Host>/<Context path=\"\" docBase=\"${sourceName}\"> \\n  <\!-- Default set of monitored resources --> \\n <WatchedResource>WEB-INF\/web.xml<\/WatchedResource> \\n <\/Context> \\n \\n <\/Host>/" ${catalinaHome}/conf/server.xml
#sed -i -e "s/<\/Host>/<Context path=\"ROOT\" docBase=\"ROOT\"> \\n <\!-- Default set of monitored resources --> \\n <WatchedResource>WEB-INF\/web.xml<\/WatchedResource> \\n <\/Context> \\n \\n <\/Host>/" ${catalinaHome}/conf/server.xml

echo "installOnUbuntu.sh: End"
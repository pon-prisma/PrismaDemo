/*******************************************************************************
* Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import java.util.concurrent.TimeUnit;
import static JmxMonitors.*


service 
{
	name "tomcat"
	icon "tomcat.gif"
	type "APP_SERVER"
	
    elastic true
	numInstances 1
	minAllowedInstances 1
	//instanceNumber e' un parametro
	maxAllowedInstances instanceNumber
	
	def instanceId = context.instanceId
	
	
	
	def currJmxPort = jmxPort
	def currHttpPort = port
	def currAjpPort = ajpPort 
	
	
	compute 
	{ 
		//dimension e' un parametro
		template dimension 
	}

	lifecycle 
	{
		
		details 
		{
			//def currPublicIP = System.getenv()["CLOUDIFY_AGENT_ENV_PUBLIC_IP"]	
			def currPublicIP	

			if (!System.getenv()["CLOUDIFY_AGENT_ENV_PUBLIC_IP"]) 
				{
					// Se CLOUDIFY_AGENT_ENV_PUBLIC_IP è vuoto prendo l'indirizzo IP privato.
					currPublicIP = System.getenv()["CLOUDIFY_AGENT_ENV_PRIVATE_IP"]
				} 
				else 
					{
						currPublicIP = System.getenv()["CLOUDIFY_AGENT_ENV_PUBLIC_IP"]					
					}

			def machineID = System.getenv()["CLOUDIFY_CLOUD_MACHINE_ID"]
			def vmname =  InetAddress.getLocalHost().getHostName()
			def servizi = "[{name:tomcat,port:${currHttpPort}}]"
			
			//def loadBalancerPrivateIP = context.attributes.thisApplication["loadBalancerPrivateIP"]

			
			def tomcatURL = "${currPublicIP}:${currHttpPort}"			
			def contextPath = context.attributes.thisInstance["contextPath"]	

			def applicationURL

			if (contextPath == "ROOT") 
			{
				applicationURL = "${currPublicIP}:${currHttpPort}"					
			}
				else
				{
					applicationURL = "${currPublicIP}:${currHttpPort}/${contextPath}"
				}					
			

			context.attributes.thisInstance["vmUuid"] = "${machineID}"
			context.attributes.thisInstance["vmIp"] = "${currPublicIP}"
			context.attributes.thisInstance["vmName"] = "${vmname}"
			context.attributes.thisInstance["services"] = "${servizi}"
			context.attributes.thisInstance["applicationURL"] = "${applicationURL}"
			
			println "tomcat-service.groovy: applicationURL is ${applicationURL}"
			
			return [
				"VM_IP":"${currPublicIP}",
				"VM_Port":"${currHttpPort}",	
				"VM_ID":"${machineID}",
				"Tomcat URL":"<a href=\"${tomcatURL}\" target=\"_blank\">${tomcatURL}</a>",
				"Application URL":"<a href=\"${applicationURL}\" target=\"_blank\">${applicationURL}</a>",
				"Context Path Tomcat":"<a href=\"${contextPath}\" target=\"_blank\">${contextPath}</a>",
				"services":"${servizi}"
			]
		}

		monitors 
		{
			def contextPath = context.attributes.thisInstance["contextPath"]
			if (contextPath == 'ROOT') contextPath="" // ROOT means "" by convention in Tomcat
			
			def metricNamesToMBeansNames = 
			[
				"Current Http Threads Busy": ["Catalina:type=ThreadPool,name=\"http-bio-${currHttpPort}\"", "currentThreadsBusy"],
				"Current Http Thread Count": ["Catalina:type=ThreadPool,name=\"http-bio-${currHttpPort}\"", "currentThreadCount"],
				"Backlog": ["Catalina:type=ProtocolHandler,port=${currHttpPort}", "backlog"],
				"Total Requests Count": ["Catalina:type=GlobalRequestProcessor,name=\"http-bio-${currHttpPort}\"", "requestCount"],
				"Active Sessions": ["Catalina:type=Manager,context=/${contextPath},host=localhost", "activeSessions"],
			]
			return getJmxMetrics("127.0.0.1",currJmxPort,metricNamesToMBeansNames)
		}
		
		//Eventi del ciclo di vita dell'istanza del servizio, scritti nei rispettivi file.groovy ed invocati dal ESM
		init    "tomcat_init.groovy"
		
		install "tomcat_install.groovy"
		
		start   "tomcat_start.groovy"
		
		preStop "tomcat_stop.groovy"
		
		startDetectionTimeoutSecs 240
		
		//Evento del ciclo di vita dell'istanza del servizio, scritto come closure
		startDetection 
		{
			println "tomcat-service.groovy(startDetection): arePortsFree http=${currHttpPort} ajp=${currAjpPort} ..."
			//Sto dicendo che quelle porte non sono piu' libere, cioe' risultano utilizzate da java (Cloudify)
			// quindi il processo puo' essere considerato partito a tutti gli effetti
			
			!ServiceUtils.arePortsFree([currHttpPort, currAjpPort] )
		}


		
		//Evento del ciclo di vita
		//Dopo che l'istanza corrente ha avviato il server tomcat, se e' stato richiesto il Load Balancing
		//la registro su ApacheLB (che ovviamente dovra' essere creato come primo servizio)
		//usando l'IP privato. Questo vuol dire che conviene nn assegnare necessariamente un IP pubblico a ciascuna istanza,
		//se non si ha l'intenzione di raggiungerla direttamente
		postStart 
		{
			if ( useLoadBalancer ) 
			{ 
				println "tomcat-service.groovy: tomcat Post-start - useLoadBalancer = ${useLoadBalancer} - Registrazione istanza Tomcat su ApacheLB..."
				
				
				//Recupero il context del servizio ApacheLB, affinche' io possa operare nel context corrente (quello di Tomcat)
				//Il context di ApacheLB lo salvo con il nome apacheService
				def apacheService = context.waitForService("LB_apache", 180, TimeUnit.SECONDS)
				println "tomcat-service.groovy: Chiamata del custom command add-node del servizio LB_apache ..."
				
				// Compongo l'URL al quale è raggiungibile il war di Tomcat, per aggiungerlo ad ApacheLB
				
				//recupero l'IP privato della istanza
				def ipAddress = context.privateAddress
				if (ipAddress == null || ipAddress.trim() == "") ipAddress = context.publicAddress
				println "tomcat-service.groovy: ipAddress is ${ipAddress} ..."				
				//Recupero il contextPath, che sara' probabilmente contextPath=nome_ricetta (es. apachetomcat)
				def contextPath = context.attributes.thisInstance["contextPath"]
				//if (contextPath == 'ROOT') contextPath="" // ROOT means "" by convention in Tomcat
				//compongo l'URL
				//def currURL="http://${ipAddress}:${currHttpPort}/${contextPath}"
				//def currURL="ajp://${ipAddress}:${currAjpPort}/${contextPath}"
				def currURL
				if (contextPath == "ROOT") 
				{
					currURL="ajp://${ipAddress}:${currAjpPort}"				
				}
					else
					{
					
					currURL="ajp://${ipAddress}:${currAjpPort}/${contextPath}"
					}
				
				println "tomcat-service.groovy: Sto per aggiungere l'URL ${currURL} ad ApacheLB ..."
				//richiamo il comando custom di ApacheLB per aggiungere quell'URL
				apacheService.invoke("addNode", currURL as String, instanceId as String)
				println "tomcat-service.groovy: tomcat Post-start ended"
				
				//NB: Se saranno aggiunte altre istanze di Tomcat, quello che cambiera' nel LB tra
				//una istanza e l'altra sara' l'IP privato "ipAddress".
				
				
			}
		}
		
		//Evento del ciclo di vita
		postStop 
		{
			if ( useLoadBalancer ) 
			{ 
				println "tomcat-service.groovy: tomcat Post-stop - useLoadBalancer = ${useLoadBalancer} - Cancellazione istanza Tomcat da ApacheLB..."
				
				
				try { 
					//Recupero il context del servizio ApacheLB, affinche' io possa operare nel context corrente (quello di Tomcat)
					//Il context di ApacheLB lo salvo con il nome apacheService
					def apacheService = context.waitForService("LB_apache", 180, TimeUnit.SECONDS)
					
					if ( apacheService != null ) 
					{ 
						def ipAddress = context.privateAddress
						if (ipAddress == null || ipAddress.trim() == "") ipAddress = context.publicAddress
						println "tomcat-service.groovy: ipAddress is ${ipAddress} ..."
						def contextPath = context.attributes.thisInstance["contextPath"]
						//if (contextPath == 'ROOT') contextPath="" // ROOT means "" by convention in Tomcat
						//compongo l'URL da rimuovere
						//def currURL="http://${ipAddress}:${currHttpPort}/${contextPath}"
						//def currURL="ajp://${ipAddress}:${currAjpPort}/${contextPath}"
						def currURL
						if (contextPath == "ROOT") 
						{
							currURL="ajp://${ipAddress}:${currAjpPort}"				
						}
							else
						{
					
							currURL="ajp://${ipAddress}:${currAjpPort}/${contextPath}"
						}
						println "tomcat-service.groovy: About to remove ${currURL} from LB_apache ..."
						apacheService.invoke("removeNode", currURL as String, instanceId as String)
					}
					else {
						println "tomcat-service.groovy: waitForService LB_apache ha restituito null"
					}
				}
				catch (all) {
					println "tomcat-service.groovy: Exception in Post-stop: " + all
				}
				println "tomcat-service.groovy: tomcat Post-stop ended"
				
				
			}
		}
		
	}


	
/*
	network 
	{
		port = currHttpPort
		protocolDescription = "HTTP"
		accessRules {
			incoming ([
				accessRule {
					type "PUBLIC"
					portRange currHttpPort
					target "0.0.0.0/0"
				}
			])
		}
	}
	
*/

	network 
	{
		port = currHttpPort
		protocolDescription = "HTTP"
		accessRules {
			incoming ([
				accessRule {
					type "APPLICATION"
					portRange currHttpPort
				}
			])
		}
	}


	 //The time (in seconds) that scaling rules are disabled after
     //scale in (instances removed) or scale out (instances added).
	scaleCooldownInSeconds 300
	
	//The time (in seconds) between two consecutive metric samples.
    //Used together with scaling rules 
	samplingPeriodInSeconds 1

	// Definisce una "automatic scaling rule" basata su una metrica di tipo "counter"
	scalingRules ([
		scalingRule {

			serviceStatistics {
				//metrica che verrà usata in ciascuna istanza del servizio
				metric "Current Http Threads Busy"
				
				//tipo di statistica che verrà usata per elaborare le metriche 
				//relative alle n istanze del servizio attive in quel momento
				statistics Statistics.maximumOfMaximums
				
				//Finestra temporale (in seconds) all'interno della quale verranno eseguiti 
				//i campionamenti della metrica per le n istanze del servizio attive. 
				//Il numero dei campioni all'interno della finestra è uguale alla durata della finestra 
				//divisono per il periodo di campionamento. Default value: 300 
				movingTimeRangeInSeconds 10
			}
			
			//soglia Alta: quando la statistica della metrica supera questo valore, vengono aggiunte un numero di istanze 
			//del servizio in questione pari a "instancesIncrease". Dopo di che, prima di sondare nuovamente la metrica, si
			//attende per un periodo pari a "scaleCooldownInSeconds"
			highThreshold 
			{
				value 4
				instancesIncrease 1
			}
			//soglia Bass: quando la statistica della metrica supera questo valore, vengono rimosse un numero di istanze 
			//del servizio in questione pari a "instancesDecrease". Dopo di che, prima di sondare nuovamente la metrica, si
			//attende per un periodo pari a "scaleCooldownInSeconds"
			lowThreshold 
			{
				value 1
				instancesDecrease 1
			}
		}
	])
}
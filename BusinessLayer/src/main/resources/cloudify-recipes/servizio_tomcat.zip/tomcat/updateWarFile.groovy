/*******************************************************************************
Giuseppe G - Reply S.p.A.
*******************************************************************************/
import org.cloudifysource.utilitydomain.context.ServiceContextFactory
import org.cloudifysource.dsl.utils.ServiceUtils

println "updateWarFile.groovy: Starting..."

def context = ServiceContextFactory.getServiceContext()
def config  = new ConfigSlurper().parse(new File("${context.serviceDirectory}/tomcat-service.properties").toURL())
def instanceId = context.instanceId

def warUrl=context.attributes.thisService["warUrl"] 
println "updateWarFile.groovy: warUrl is ${warUrl}"

if (! warUrl) return "warUrl is null. So we do nothing."

def catalinaBase = context.attributes.thisInstance["catalinaBase"]
def contextPath = context.attributes.thisInstance["contextPath"]

def installDir = System.properties["user.home"]+ "/.cloudify/${config.serviceName}" + instanceId
def applicationWar = "${installDir}/${config.warName?: new File(warUrl).name}"

new AntBuilder().sequential {
	if ( warUrl.toLowerCase().startsWith("http") || warUrl.toLowerCase().startsWith("ftp")) {
		echo(message:"Getting ${warUrl} to ${applicationWar} ...")
		ServiceUtils.getDownloadUtil().get("${warUrl}", "${applicationWar}", false)
	}
	else {
		echo(message:"Copying ${context.serviceDirectory}/${warUrl} to ${applicationWar} ...")
		copy(tofile: "${applicationWar}", file:"${context.serviceDirectory}/${warUrl}", overwrite:true)
	}
}

File ctxConf = new File("${catalinaBase}/conf/Catalina/localhost/${contextPath}.xml")
if (ctxConf.exists()) {
	assert ctxConf.delete()
} else {
	new File(ctxConf.getParent()).mkdirs()
}
assert ctxConf.createNewFile()
ctxConf.append("<Context docBase=\"${applicationWar}\" />")

println "updateWarFile.groovy: End"
return true

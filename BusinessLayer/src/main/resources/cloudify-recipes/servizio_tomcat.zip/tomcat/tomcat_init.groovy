/*******************************************************************************
* Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.cloudifysource.utilitydomain.context.ServiceContextFactory

def context = ServiceContextFactory.getServiceContext()
def config = new ConfigSlurper().parse(new File("${context.serviceDirectory}/tomcat-service.properties").toURL())
def instanceId = context.instanceId

println "tomcat_init.groovy: Initialize tomcat - Giuseppe..."


// Carica le configurazioni per Tomcat definite o nel properties (config) o nel service descriptor file o nel context (es applicationName)
//condizione ? se_condizione_e'_vera : se_condizione_e'_falsa
def catalinaHome = config.catalinaHome ?: "${context.serviceDirectory}/${config.servicePackName}"
def catalinaBase = config.catalinaBase ?: catalinaHome
def catalinaOpts = config.catalinaOpts ?: ""
def javaOpts = config.javaOpts ?: ""

//Recupero il nome del war e del sorgente per il contextPath
def sourcePath = "${config.sourcePath}"
def sourcePathValues
def sourcePathValuesLength
def warName
def sourceName

if ( sourcePath.startsWith("http") || sourcePath.startsWith("https") ) 
{
	warName = "${config.warName}"
	println "tomcat_init.groovy: Il sorgente e' sul repository"+warName
	//sourcePathValues = sourcePath.split('/')
	//sourcePathValuesLength = sourcePathValues.length
	//warName = sourcePathValues[sourcePathValuesLength - 1]
	
	//sourceName sara' uguale a ROOT
	sourceName = warName - ".war"
}		
else 
{
	println "tomcat_init.groovy: Il sorgente e' nella ricetta"
	warName = "${config.warName}"
	//warName = sourcePath
	//sourceName sara' uguale a ROOT
	sourceName = warName - ".war" 
}

//def sourceName="upDial"
//def warName = "${sourceName}.war"

//def contextPath = config.contextPath ?: (context.applicationName != "default")? context.applicationName : "ROOT"
//def contextPath = "${sourceName}"

// Voglio che l'URl sia IP_tomcat:porta
def contextPath = "ROOT"

// Assegno le configurazioni al contesto di questa istanza
context.attributes.thisInstance["catalinaHome"] = "${catalinaHome}"
context.attributes.thisInstance["catalinaBase"] = "${catalinaBase}"
context.attributes.thisInstance["catalinaOpts"] = "${catalinaOpts}"
context.attributes.thisInstance["javaOpts"] = "${javaOpts}"

context.attributes.thisInstance["sourceName"] = "${sourceName}"
context.attributes.thisInstance["warName"] = "${warName}"
context.attributes.thisInstance["contextPath"] = "${contextPath}"

context.attributes.thisInstance["envVar"] = config.envVar




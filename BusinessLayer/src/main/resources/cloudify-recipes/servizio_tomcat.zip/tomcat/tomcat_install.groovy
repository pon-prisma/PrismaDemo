/*******************************************************************************
* Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.cloudifysource.utilitydomain.context.ServiceContextFactory
import org.cloudifysource.dsl.utils.ServiceUtils

def context = ServiceContextFactory.getServiceContext()
def instanceId = context.instanceId
def config = new ConfigSlurper().parse(new File("${context.serviceDirectory}/tomcat-service.properties").toURL())


println "tomcat_install.groovy: Installazione di tomcat... - Giuseppe"

// Carico la configurazione dal contesto di questa istanza del servizio ed il warURL
def catalinaHome = context.attributes.thisInstance["catalinaHome"]
def catalinaBase = context.attributes.thisInstance["catalinaBase"]
def contextPath = context.attributes.thisInstance["contextPath"]

//application
def sourcePath = "${config.sourcePath}"
def warName = context.attributes.thisInstance["warName"]
def sourceName = context.attributes.thisInstance["sourceName"]

//definisco il nome della cartella di appoggio nella quale verranno scaricati i file ed estratti, per poi essere spostati in serviceDirectory
def unzipDir = System.properties["user.home"]+ "/.cloudify"
def serviceDirectory = "${context.serviceDirectory}"

//apache-tomcat
def downloadPath = "${config.downloadPath}"
def servicePackName = "${config.servicePackName}"
def userTomcat = "${config.userTomcat}"
def passTomcat = "${config.passTomcat}"


//port
def port = "${config.port}"	
def ajpPort = "${config.ajpPort}"
def shutdownPort = "${config.shutdownPort}"	

//Connector JDBC
def mysqlJDBC = "${config.mysqlJDBC}"
def postgresJDBC = "${config.postgresJDBC}"

//Eseguo il file di installazione del servizio
script="installOnUbuntu.sh"
new AntBuilder().sequential 
{
	echo(message:"tomcat_install.groovy: Creo la directory ${unzipDir} ...")
	mkdir(dir:"${unzipDir}")
	
		//context.serviceDirectory  è la directory dove si trova la ricetta del servizio
	    //Faccio  in modo che la directory del servizio sia eseguibile....
		echo(message:"tomcat_install.groovy: Dentro builder. Eseguo Chmodding +x della cartella ${context.serviceDirectory} per eseguire gli script.sh...")
		chmod(dir:"${context.serviceDirectory}", perm:"+x", includes:"*.sh")

		echo(message:"tomcat_install.groovy: Eseguo ${context.serviceDirectory}/${script} ...")		
		exec(executable: "${context.serviceDirectory}/${script}",failonerror: "true") {
			arg(value:"${serviceDirectory}")
			arg(value:"${unzipDir}")
			arg(value:"${downloadPath}")
			arg(value:"${servicePackName}")
			arg(value:"${sourcePath}")
			arg(value:"${warName}")
			arg(value:"${catalinaHome}")			
			arg(value:"${contextPath}")
			arg(value:"${port}")	
			arg(value:"${ajpPort}")	
			arg(value:"${shutdownPort}")	
			arg(value:"${mysqlJDBC}")	
			arg(value:"${postgresJDBC}")
			arg(value:"${userTomcat}")	
			arg(value:"${passTomcat}")
			arg(value:"${sourceName}")
		}
	
}

println "tomcat_install.groovy: Tomcat installazione terminata"

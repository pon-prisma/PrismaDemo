/*******************************************************************************
Giuseppe G. - Reply S.p.A.
*******************************************************************************/
service {
	
	name "LB_apache"
	icon "feather-small.gif"
	type "WEB_SERVER"
	numInstances 1

	compute {
		template "small_silver_UBUNTU12"
	}

	lifecycle {	

		details {
			

			def currPublicIP
			

			if (!System.getenv()["CLOUDIFY_AGENT_ENV_PUBLIC_IP"]) 
				{
					// Se CLOUDIFY_AGENT_ENV_PUBLIC_IP è vuoto prendo l'indirizzo IP privato.
					currPublicIP = System.getenv()["CLOUDIFY_AGENT_ENV_PRIVATE_IP"]
				} 
				else 
					{
						currPublicIP = System.getenv()["CLOUDIFY_AGENT_ENV_PUBLIC_IP"]					
					}

			//IP privato da usare nei Security Group di Tomcat
			//context.attributes.thisApplication["loadBalancerPrivateIP"] = System.getenv()["CLOUDIFY_AGENT_ENV_PRIVATE_IP"]

			def machineID = System.getenv()["CLOUDIFY_CLOUD_MACHINE_ID"]
			def vmname =  InetAddress.getLocalHost().getHostName()
			def servizi = "[{name:apache,port:${currentPort}}]"



			def loadBalancerURL	= "http://${currPublicIP}:${currentPort}"
			def balancerManagerURL = "${loadBalancerURL}/balancer-manager"			
			//def ctxPath=("default" == context.applicationName)?"":"${context.applicationName}"
			def ctxPath = ""

			def applicationURL
			if (ctxPath == "") 
			{
				applicationURL = "${loadBalancerURL}"				
			}
				else
				{
					applicationURL = "${loadBalancerURL}/${ctxPath}"
					
				}	
			

			context.attributes.thisInstance["vmUuid"] = "${machineID}"
			context.attributes.thisInstance["vmIp"] = "${currPublicIP}"
			context.attributes.thisInstance["vmName"] = "${vmname}"
			context.attributes.thisInstance["services"] = "${servizi}"
			context.attributes.thisInstance["applicationURL"] = "${applicationURL}"

				return [
					"BalancerManager URL":"<a href=\"${balancerManagerURL}\" target=\"_blank\">${balancerManagerURL}</a>",
					"Application URL":"<a href=\"${applicationURL}\" target=\"_blank\">${applicationURL}</a>",
					"services":"${servizi}"
				]
		}	
	
		install "LB_apache_install.groovy"
		postInstall "LB_apache_postInstall.groovy"
		start ([
			"Win.*":"run.bat",
			"Linux.*":"LB_apache_start.groovy"
			])
			
		startDetectionTimeoutSecs 800
		startDetection {			
			ServiceUtils.isPortOccupied(currentPort)
		}	
		
		preStop ([	
			"Win.*":"killAllHttpd.bat",		
			"Linux.*":"LB_apache_stop.groovy"
			])
		shutdown ([	
			"Win.*": "echo There's no need to uninstall on Windows"  ,
			"Linux.*":"LB_apache_uninstall.groovy"
		])
			
		locator {			
			def myPids = ServiceUtils.ProcessUtils.getPidsWithQuery("State.Name.re=httpd|apache")
			println ":LB_apache-service.groovy: current PIDs: ${myPids}"
			return myPids
        }
			
			
	}
	
	customCommands ([
		"addNode" : "LB_apache_addNode.groovy",
		"removeNode" : "LB_apache_removeNode.groovy",
		"load" : "LB_apache-load.groovy"		
	])
	
	
	network {
		port currentPort
		protocolDescription "HTTP"
	}
}

/*******************************************************************************
Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.hyperic.sigar.OperatingSystem
import org.cloudifysource.utilitydomain.context.ServiceContextFactory

context = ServiceContextFactory.getServiceContext()

def os = OperatingSystem.getInstance()
def currVendor=os.getVendor()
def stopScript
switch (currVendor) {
	case ["Ubuntu", "Debian", "Mint"]:			
		stopScript="${context.serviceDirectory}/stopOnUbuntu.sh"
		break		
	case ["Red Hat", "CentOS", "Fedora", "Amazon",""]:			
		stopScript="${context.serviceDirectory}/stop.sh"
		break					
	default: throw new Exception("Support for ${currVendor} is not implemented")
}

builder = new AntBuilder()
builder.sequential {
	exec(executable:"${stopScript}", osfamily:"unix")        	
}

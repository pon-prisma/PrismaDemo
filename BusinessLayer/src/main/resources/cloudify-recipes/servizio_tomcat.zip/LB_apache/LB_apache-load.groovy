/*******************************************************************************
Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.hyperic.sigar.OperatingSystem
import org.cloudifysource.utilitydomain.context.ServiceContextFactory


/* In order to test your application under load, you can use this "load" custom command.
   It uses Apache Bench which is installed by default with apache.
   
   
   The following will fire 350000 requests on http://LB_IP_ADDRESS:LB_PORT/ with 100 concurrent requests each time:
     invoke LB_apache load 350000 100

   The following will fire 200000 requests on http://LB_IP_ADDRESS:LB_PORT/petclinic with 240 concurrent requests each time: 
     invoke LB_apache load 200000 240 petclinic
*/

config = new ConfigSlurper().parse(new File("LB_apache-service.properties").toURL())

def requests = args[0]
def concurrency= args[1]

def loadBalancerURL

context = ServiceContextFactory.getServiceContext()

def ctxPath

if ( args.length <3 ) { 
	//ctxPath=("default" == context.applicationName)?"/":"/${context.applicationName}"
	ctxPath="/"
}	
else {	
	ctxPath = args[2]
	if ( !ctxPath.startsWith("/") ) {
		ctxPath="/${ctxPath}"
	}
}

loadBalancerURL	= "http://127.0.0.1:${config.currentPort}${ctxPath}"

def os = OperatingSystem.getInstance()
def currVendor=os.getVendor()
def abScript
switch (currVendor) {
	case ["Ubuntu", "Debian", "Mint","Red Hat", "CentOS", "Fedora", "Amazon",""]:			
		abScript="${context.serviceDirectory}/load.sh"
		break	
	case ~/.*(?i)(Microsoft|Windows).*/:
		abScript="${context.serviceDirectory}/load.bat"
		break	
	default: throw new Exception("Support for ${currVendor} is not implemented")
}

builder = new AntBuilder()
builder.sequential {
	echo(message:"LB_apache-load.groovy: Running ${abScript} -v INFO -n ${requests} -c ${concurrency} ${loadBalancerURL}. OS is ${currVendor} ...")
	exec(executable:"${abScript}",failonerror: "true") {
		arg(value:"${requests}")
		arg(value:"${concurrency}")
		arg(value:"${loadBalancerURL}")		
	}
}

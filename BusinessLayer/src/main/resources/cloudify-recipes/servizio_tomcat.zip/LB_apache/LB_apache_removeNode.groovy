/*******************************************************************************
Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.hyperic.sigar.OperatingSystem
import org.cloudifysource.utilitydomain.context.ServiceContextFactory

context = ServiceContextFactory.getServiceContext()
config = new ConfigSlurper().parse(new File("LB_apache-service.properties").toURL())


def node = args[0]
def instanceID= args[1]

def proxyBalancerFullPath = context.attributes.thisInstance["proxyBalancerPath"]

println "removeNode: About to remove ${node} instance (${instanceID}) to /etc/apache2/sites-available/default..."
def proxyConfigFile = new File("${proxyBalancerFullPath}")
			
def routeStr=""
if ( "${config.useStickysession}" == "true" ) {
	//routeStr=" route=" + instanceID
	routeStr=" route=" + "tomcat"
}
	
def balancerMemberText="BalancerMember " + node + routeStr

def configText = proxyConfigFile.text
def modifiedConfig = configText.replace("${balancerMemberText}", "")
proxyConfigFile.text = modifiedConfig
println "removeNode: Removed ${node} from /etc/apache2/sites-available/default - text is now : ${modifiedConfig}..."

def balancerMembers=context.attributes.thisService["balancerMembers"]
if ( balancerMembers != null ) {
	balancerMembers=balancerMembers.replace(",${balancerMemberText},","")
	if ( balancerMembers == "" ) {
		balancerMembers = null
	}
}
	

context.attributes.thisService["balancerMembers"]=balancerMembers
println "removeNode: Cleaned ${node} from context balancerMembers"

currOs=System.properties['os.name']
println "removeNode: About to kill ${currOs} processes ..."
if ("${currOs}".toLowerCase().contains('windows')) {
	def currCmd="taskkill /t /im httpd* /f"
	println "removeNode: About to kill httpd.."
	currCmd.execute()
	println "removeNode: Killed httpd"
}
else {
	def os = OperatingSystem.getInstance()
	def currVendor=os.getVendor()
	def stopScript
	switch (currVendor) {
		case ["Ubuntu", "Debian", "Mint"]:			
			stopScript="${context.serviceDirectory}/stopOnUbuntu.sh"
			break		
		case ["Red Hat", "CentOS", "Fedora", "Amazon",""]:			
			stopScript="${context.serviceDirectory}/stop.sh"
			break					
		default: throw new Exception("Support for ${currVendor} is not implemented")
	}

	builder = new AntBuilder()
	builder.sequential {
		exec(executable:"${stopScript}", osfamily:"unix")        	
	}
}
		
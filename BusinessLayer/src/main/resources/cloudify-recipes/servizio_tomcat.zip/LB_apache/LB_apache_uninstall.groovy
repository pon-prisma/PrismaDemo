/*******************************************************************************
Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.hyperic.sigar.OperatingSystem
import org.cloudifysource.utilitydomain.context.ServiceContextFactory

context = ServiceContextFactory.getServiceContext()


def os = OperatingSystem.getInstance()
def currVendor=os.getVendor()

def uninstallScript
switch (currVendor) {
	case ["Ubuntu", "Debian", "Mint"]:			
		uninstallScript="${context.serviceDirectory}/uninstallOnUbuntu.sh"
		break		
	case ["Red Hat", "CentOS", "Fedora", "Amazon",""]:			
		uninstallScript="${context.serviceDirectory}/uninstall.sh"
		break	
	case ~/.*(?i)(Microsoft|Windows).*/:		
		// Need to add Windows impl here
	default: 
		System.exit(0)
}

builder = new AntBuilder()
builder.sequential {			
	echo(message:"LB_apache_uninstall.groovy: Running ${uninstallScript} os is ${currVendor} ...")
	exec(executable:"${uninstallScript}", osfamily:"unix",failonerror: "true")			
}

/*******************************************************************************
Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.hyperic.sigar.OperatingSystem
import org.cloudifysource.dsl.utils.ServiceUtils;
import org.cloudifysource.utilitydomain.context.ServiceContextFactory

context = ServiceContextFactory.getServiceContext()
config = new ConfigSlurper().parse(new File("LB_apache-service.properties").toURL())

osConfig = ServiceUtils.isWindows() ? config.win32 : config.linux

downloadFile="${config.downloadFolder}/${osConfig.zipName}"

def installLinuxHttpd(context,builder,currVendor,installScript) {

	if ( context.isLocalCloud() ) {
		if ( context.attributes.thisApplication["installing"] == null || context.attributes.thisApplication["installing"] == false ) {
			context.attributes.thisApplication["installing"] = true
		}
		else {
			while ( context.attributes.thisApplication["installing"] == true ) {
				println "LB_apache_install.groovy: Waiting for apt-get/yum (on localCloud) to end on another service instance in this application... "
				sleep 10000			
			}
		}
	}

	builder.sequential {
		echo(message:"LB_apache_install.groovy: Chmodding +x ${context.serviceDirectory} ...")
		chmod(dir:"${context.serviceDirectory}", perm:"+x", includes:"*.sh")

		echo(message:"LB_apache_install.groovy: Running ${context.serviceDirectory}/${installScript} os is ${currVendor}...")
		exec(executable: "${context.serviceDirectory}/${installScript}",failonerror: "true")
	}
	
	if ( context.isLocalCloud() ) {
		context.attributes.thisApplication["installing"] = false
		println "LB_apache_install.groovy: Finished using apt-get/yum on localCloud"
	}	
}

//def installWindowsHttpd(config,osConfig,downloadFile,builder) {
//	builder.sequential {
//			echo(message:"LB_apache_install.groovy: installing on Windows...")
//			mkdir(dir:"install")
//			mkdir(dir:"${config.downloadFolder}")
//			ServiceUtils.getDownloadUtil().get("${osConfig.downloadUrl}", "${downloadFile}", true, "${osConfig.hashDownloadUrl}")
//			get(src:"${osConfig.downloadUrl}", dest:"${downloadFile}", skipexisting:true)
//			unzip(src:"${downloadFile}", dest:"install", overwrite:true)
//			copy( todir:'install' ) {
//				fileset( dir:'overrides-win' )
//			}	
//	}
//}

builder = new AntBuilder()

def os = OperatingSystem.getInstance()
def currVendor=os.getVendor()
switch (currVendor) {
		case ["Ubuntu", "Debian", "Mint"]:			
			installLinuxHttpd(context,builder,currVendor,"installOnUbuntu.sh")
			break		
		//case ["Red Hat", "CentOS", "Fedora", "Amazon",""]:			
		//	installLinuxHttpd(context,builder,currVendor,"install.sh")
		//	break					
		//case ~/.*(?i)(Microsoft|Windows).*/:		
		//	installWindowsHttpd(config,osConfig,downloadFile,builder)
		//	break
		default: throw new Exception("Support for ${currVendor} is not implemented")
}
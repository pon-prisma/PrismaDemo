/*******************************************************************************
Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.hyperic.sigar.OperatingSystem
import org.cloudifysource.utilitydomain.context.ServiceContextFactory

context = ServiceContextFactory.getServiceContext()
config = new ConfigSlurper().parse(new File("LB_apache-service.properties").toURL())


def node = args[0]
def instanceID= args[1]

def proxyBalancerFullPath = context.attributes.thisInstance["proxyBalancerPath"]

println "addNode: About to add ${node} instance (${instanceID}) to /etc/apache2/sites-available/default..."
def proxyConfigFile = new File("${proxyBalancerFullPath}")
def configText = proxyConfigFile.text
def routeStr=""
if ( "${config.useStickysession}" == "true" ) {

	routeStr=" route=" + "tomcat"
	//routeStr=" route=" + instanceID
}

def balancerMemberText="BalancerMember " + node + routeStr

if ( configText.contains(balancerMemberText)) {
	println "addNode: Not adding ${node} to /etc/apache2/sites-available/default because it's already there..."	
}
else { 
	def modifiedConfig = configText.replace("# Generated code - DO NOT MODIFY", "# Generated code - DO NOT MODIFY" + System.getProperty("line.separator") + "${balancerMemberText}")				
	proxyConfigFile.text = modifiedConfig
	println "addNode: Added ${node} to /etc/apache2/sites-available/default - text is now : ${modifiedConfig}..."

	def balancerMembers=context.attributes.thisService["balancerMembers"]
	if ( balancerMembers == null ) {
		balancerMembers = ""
	}
	balancerMembers +=",${balancerMemberText},"										
	context.attributes.thisService["balancerMembers"]=balancerMembers
	println "addNode: Added ${node} to context balancerMembers which is now ${balancerMembers}"


	currOs=System.properties['os.name']
	println "addNode: About to kill ${currOs} processes ..."
	if ("${currOs}".toLowerCase().contains('windows')) {
		println "addNode: About to kill httpd.."
		def currCmd="taskkill /t /im httpd* /f"
		currCmd.execute()
		println "addNode: Killed httpd"
	}
	else {
		def os = OperatingSystem.getInstance()
		def currVendor=os.getVendor()
		def stopScript
		switch (currVendor) {
			case ["Ubuntu", "Debian", "Mint"]:			
				stopScript="${context.serviceDirectory}/stopOnUbuntu.sh"
				break		
			case ["Red Hat", "CentOS", "Fedora", "Amazon",""]:			
				stopScript="${context.serviceDirectory}/stop.sh"
				break					
			default: throw new Exception("Support for ${currVendor} is not implemented")
		}

		builder = new AntBuilder()
		builder.sequential {
			exec(executable:"${stopScript}", osfamily:"unix")        	
		}
	}
}


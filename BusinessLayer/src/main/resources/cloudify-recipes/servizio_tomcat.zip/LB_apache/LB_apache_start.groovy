/*******************************************************************************
Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.hyperic.sigar.OperatingSystem
import org.cloudifysource.utilitydomain.context.ServiceContextFactory

context = ServiceContextFactory.getServiceContext()

def os = OperatingSystem.getInstance()
def currVendor=os.getVendor()
def startScript
switch (currVendor) {
	case ["Ubuntu", "Debian", "Mint"]:			
		startScript="${context.serviceDirectory}/runOnUbuntu.sh"
		break		
	case ["Red Hat", "CentOS", "Fedora", "Amazon",""]:			
		startScript="${context.serviceDirectory}/run.sh"
		break					
	default: throw new Exception("Support for ${currVendor} is not implemented")
}

builder = new AntBuilder()
builder.sequential {
	exec(executable:"${startScript}", osfamily:"unix",failonerror: "true")        	
}

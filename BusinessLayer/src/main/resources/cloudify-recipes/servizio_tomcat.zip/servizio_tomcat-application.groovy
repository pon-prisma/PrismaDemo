/*******************************************************************************
* Giuseppe G. - Reply
*******************************************************************************/
application 
{
	name="servizio_tomcat"
	
	service {
		name = "LB_apache"
	}
	service {
		name = "tomcat"
		dependsOn = ["LB_apache"]
	}
}
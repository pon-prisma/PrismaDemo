# tomcat 

**Status**: Tested  
**Description**: Tomcat 7.0.23  
**Maintainer**:       Cloudify  
**Maintainer email**: cloudifysource@gigaspaces.com  
**Contributors**:    [tamirko](https://github.com/tamirko)  
**Homepage**:   [http://www.cloudifysource.org](http://www.cloudifysource.org)  
**License**:      Apache 2.0   
**Build**: http://repository.cloudifysource.org/org/cloudifysource/2.2.0-RELEASES/gigaspaces-cloudify-2.2.0-ga-b2500.zip  
**Linux* sudoer permissions**:	Not required  
**Windows* Admin permissions**:  Not required    
**Release Date**: October 23rd 2012  


Tested on:
--------

* <strong>OpenStack</strong>: Ubuntu 12.04 

Synopsis
--------

Questa cartella contiene una ricetta che isntalla un file war "Hello World" su un application server tomcat.
Tutti i binari sono locati nella cartella tomcat1; pertanto, la VM application non necessita di una connessione ad 
Internet per scaricarli ed installarli.

La porta http di default è 8080 ma può essere modificata nel the tomcat-service.properties.
Le altre sue porte possono essere anch'esse impostate nel tomcat-service.properties.

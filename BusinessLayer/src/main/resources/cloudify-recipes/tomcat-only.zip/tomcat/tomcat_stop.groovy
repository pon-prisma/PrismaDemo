/*******************************************************************************
* Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.cloudifysource.utilitydomain.context.ServiceContextFactory
import org.cloudifysource.dsl.utils.ServiceUtils

println "tomcat_stop.groovy: Sto stoppando tomcat..."

def context = ServiceContextFactory.getServiceContext()

def catalinaHome = context.attributes.thisInstance["catalinaHome"]
def catalinaBase = context.attributes.thisInstance["catalinaBase"]



new AntBuilder().sequential 
{
	// Fermo il servizio eseguendo catalina.sh e passandogli  le variabili di ambiente ed il comando stop
	exec(executable:"${catalinaHome}/bin/catalina.sh", osfamily:"unix") 
	{
		env(key:"CLASSPATH", value: "") // reset CP to avoid side effects (Cloudify passes all the required files to Groovy in the classpath)
		env(key:"CATALINA_HOME", value: "${catalinaHome}")
		env(key:"CATALINA_BASE", value: "${catalinaBase}")
		arg(value:"stop")
	}	
	
}

println "tomcat_stop.groovy: tomcat is stopped"

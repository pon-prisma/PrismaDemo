/*******************************************************************************
* Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.cloudifysource.utilitydomain.context.ServiceContextFactory
import java.util.concurrent.TimeUnit

println "tomcat_start.groovy: Avvio del servizio Tomcat..."

def context = ServiceContextFactory.getServiceContext()
def config = new ConfigSlurper().parse(new File("${context.serviceDirectory}/tomcat-service.properties").toURL())
def instanceId = context.instanceId
println "tomcat_start.groovy: This tomcat instance Id is ${instanceId}"

//carico le configurazioni del contesto e le stampo a video
def catalinaHome = context.attributes.thisInstance["catalinaHome"]
println "tomcat_start.groovy: tomcat(${instanceId}) catalinaHome ${catalinaHome}"
def catalinaBase = context.attributes.thisInstance["catalinaBase"]
println "tomcat_start.groovy: tomcat(${instanceId}) catalinaBase ${catalinaBase}"
def catalinaOpts = context.attributes.thisInstance["catalinaOpts"]
println "tomcat_start.groovy: tomcat(${instanceId}) catalinaOpts ${catalinaOpts}"
def javaOpts = context.attributes.thisInstance["javaOpts"]
println "tomcat_start.groovy: tomcat(${instanceId}) javaOpts ${javaOpts}"
def envVar = context.attributes.thisInstance["envVar"]


//Se è stata richiesta l'allocazione di un DB (poichè nella ricetta c'è la dipendenza da questo servizio,
//aspetto che esso sia stato allocato e recupero le informazioni su esso (IP, porta di ascolto, etc...)
if ( config.dbServiceName &&  "${config.dbServiceName}" != "NO_DB_REQUIRED") {
	println "tomcat_start.groovy: waiting for ${config.dbServiceName}..."
	def dbService = context.waitForService(config.dbServiceName, 20, TimeUnit.SECONDS)
	def dbInstances = dbService.waitForInstances(dbService.numberOfPlannedInstances, 60, TimeUnit.SECONDS) 
	def dbServiceHost = dbInstances[0].hostAddress
	envVar.put(config.dbHostVarName, "${dbServiceHost}")
	println "tomcat_start.groovy: ${config.dbServiceName} host is ${dbServiceHost}"
	def dbServiceInstances = context.attributes[config.dbServiceName].instances
	dbServicePort = dbServiceInstances[1].port
	envVar.put(config.dbPortVarName, "${dbServicePort}")
	println "tomcat_start.groovy: ${config.dbServiceName} port is ${dbServicePort}"
}
println "tomcat_start.groovy: tomcat(${instanceId}) envVar ${envVar}"



currJmxPort=config.jmxPort
println "tomcat_start.groovy: jmx port is ${currJmxPort}"


//Setting delle variabili di ambiente di questa istanza
new AntBuilder().sequential 
{
	// Avvio il servizio eseguendo catalina.sh e passandogli  le variabili di ambiente ed il comando run 
	exec(executable:"${catalinaHome}/bin/catalina.sh", osfamily:"unix") 
	{
		env(key:"CLASSPATH", value: "") // reset CP to avoid side effects (Cloudify passes all the required files to Groovy in the classpath)
			envVar.each
			{
				env(key:it.key, value:it.value)
			}
		//env(key:"CATALINA_HOME", value: "${catalinaHome}")
		//env(key:"CATALINA_BASE", value: "${catalinaBase}")
		env(key:"CATALINA_OPTS", value: "${catalinaOpts} -Dcom.sun.management.jmxremote.port=${currJmxPort} -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.authenticate=false")
		//env(key:"JAVA_OPTS", value: "${javaOpts}")
		arg(value:"run")
	}	
	
}

/*******************************************************************************
* G. Galeota - Reply S.p.A.
*******************************************************************************/
import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory as JmxFactory
import javax.management.remote.JMXServiceURL as JmxUrl

/**
 * Connect to a JMX server over RMI
 */
 
class JmxMonitors {

	def static urlToConnection = [:]
	
	 
	def static connectRMI(host, port) {
		if (urlToConnection["${host:port}"] == null)
			urlToConnection["${host:port}"] = JmxFactory.connect(new JmxUrl("service:jmx:rmi:///jndi/rmi://${host}:${port}/jmxrmi"))	
		return urlToConnection["${host:port}"]
	}
	
	/**
	 * Get a JMX attribute
	 */
	def static getJMXAttribute(server, objectName, attributeName) {
		def connection = server.MBeanServerConnection
		String[] names = connection.queryNames(new ObjectName(objectName), null)
		if (names.length > 0)
				return (new GroovyMBean(connection, names[0]))[attributeName]
		return 0;
	}
	
		/* Returns a map of metrics values */ 
	def static getJmxMetrics(host,jmxPort,metricNamesToMBeansNames) {
		def server = connectRMI(host, jmxPort)
		
		def metrics  = [:]
	
		metricNamesToMBeansNames.each{metricName,objectsArr->
			def objectName=objectsArr[0]
			def attributeName=objectsArr[1]
			def currMetricValue = getJMXAttribute(server,objectName , attributeName) 		
			metrics.put(metricName,currMetricValue)
		}
		
		
	//	server.close()
		return metrics
	}

}


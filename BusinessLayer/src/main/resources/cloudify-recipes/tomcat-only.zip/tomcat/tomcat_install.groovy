/*******************************************************************************
* Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.cloudifysource.utilitydomain.context.ServiceContextFactory
import org.cloudifysource.dsl.utils.ServiceUtils

def context = ServiceContextFactory.getServiceContext()
def instanceId = context.instanceId
def config = new ConfigSlurper().parse(new File("${context.serviceDirectory}/tomcat-service.properties").toURL())


println "tomcat_install.groovy: Installazione di tomcat... - Giuseppe"

// Carico la configurazione dal contesto di questa istanza del servizio ed il warURL
def catalinaHome = context.attributes.thisInstance["catalinaHome"]
def catalinaBase = context.attributes.thisInstance["catalinaBase"]
def contextPath = context.attributes.thisInstance["contextPath"]

//definisco il nome della cartella di appoggio nella quale verranno scaricati i file ed estratti, per poi essere spostati in serviceDirectory
def unzipDir = System.properties["user.home"]+ "/.cloudify"
//definisco il nome di quello che sarà il war (es. helloworld.war)
def applicationWar = "${catalinaHome}/webapps/${config.warName}"

def serviceDirectory = "${context.serviceDirectory}"
//apache-tomcat
def downloadPath = "${config.downloadPath}"
def servicePackName = "${config.servicePackName}"
def userTomcat = "${config.userTomcat}"
def passTomcat = "${config.passTomcat}"


//application
def sourcePath = "${config.sourcePath}"
def sourceName = "${config.sourceName}"

//port
def port = "${config.port}"	
def ajpPort = "${config.ajpPort}"
def shutdownPort = "${config.shutdownPort}"	

//Dati VM
def machineID = context.attributes.thisInstance["machineID"]
def currPublicIP = context.attributes.thisInstance["currPublicIP"]

//Connector JDBC
def mysqlJDBC = "${config.mysqlJDBC}"
def postgresJDBC = "${config.postgresJDBC}"


println "tomcat_install.groovy: Passo le seguenti variabili..."

println "tomcat_install.groovy: var serviceDirectory =  ${serviceDirectory}..."
println "tomcat_install.groovy: var unzipDir =  ${unzipDir}..."

println "tomcat_install.groovy: var downloadPath =  ${downloadPath}..."
println "tomcat_install.groovy: var servicePackName =  ${servicePackName}..."


println "tomcat_install.groovy: var sourcePath =  ${sourcePath}..."
println "tomcat_install.groovy: var sourceName =  ${sourceName}..."

println "tomcat_install.groovy: var catalinaHome =  ${catalinaHome}..."
println "tomcat_install.groovy: var contextPath =  ${contextPath}..."

println "tomcat_install.groovy: var port =  ${port}..."
println "tomcat_install.groovy: var ajpPort =  ${ajpPort}..."
println "tomcat_install.groovy: var shutdownPort =  ${shutdownPort}..."

println "tomcat_install.groovy: var userTomcat =  ${userTomcat}..."
println "tomcat_install.groovy: var passTomcat =  ${passTomcat}..."

println "tomcat_install.groovy: var mysqlJDBC =  ${mysqlJDBC}..."
println "tomcat_install.groovy: var postgresJDBC =  ${postgresJDBC}..."


script="installOnUbuntu.sh"
new AntBuilder().sequential 
{
	echo(message:"tomcat_install.groovy: Creo la directory ${unzipDir} ...")
	mkdir(dir:"${unzipDir}")
	
		//context.serviceDirectory  è la directory dove si trova la ricetta del servizio
	    //Faccio  in modo che la directory del servizio sia eseguibile....
		echo(message:"tomcat_install.groovy: Dentro builder. Eseguo Chmodding +x della cartella ${context.serviceDirectory} per eseguire gli script.sh...")
		chmod(dir:"${context.serviceDirectory}", perm:"+x", includes:"*.sh")

		echo(message:"tomcat_install.groovy: Eseguo ${context.serviceDirectory}/${script} ...")		
		exec(executable: "${context.serviceDirectory}/${script}",failonerror: "true") {
			arg(value:"${serviceDirectory}")
			arg(value:"${unzipDir}")
			arg(value:"${downloadPath}")
			arg(value:"${servicePackName}")
			arg(value:"${sourcePath}")
			arg(value:"${sourceName}")
			arg(value:"${catalinaHome}")			
			arg(value:"${contextPath}")
			arg(value:"${port}")	
			arg(value:"${ajpPort}")	
			arg(value:"${shutdownPort}")	
			arg(value:"${userTomcat}")	
			arg(value:"${passTomcat}")
			arg(value:"${mysqlJDBC}")	
			arg(value:"${postgresJDBC}")
			arg(value:"${machineID}")
			arg(value:"${currPublicIP}")			
			
		}
	
	
	
	//if ( config.downloadPath.toLowerCase().startsWith("http") || config.downloadPath.toLowerCase().startsWith("ftp")) 
	//e' popolato l'URL downloadPat; quindi scarico da internet
	//{
	//	echo(message:"Sto scaricando ${config.downloadPath} in ${unzipDir}/${config.zipName} ...")
	//	ServiceUtils.getDownloadUtil().get("${config.downloadPath}", "${unzipDir}/${config.zipName}", true, "${config.hashDownloadPath}")
	//}		
	//else 
	//il file di installazione e' presente gia' nella serviceDirectory, cioe' nella cartella della ricetta
	//Quindi la copio dalla cartella corrente della ricetta nella cartella in cui verra' installato tomcat
	//{
	//	echo(message:"Sto copiando da ${context.serviceDirectory}/${config.downloadPath} in ${unzipDir}/${config.zipName} ...")
	//	copy(tofile: "${unzipDir}/${config.zipName}", file:"${context.serviceDirectory}/${config.downloadPath}", overwrite:false)
	//}
	//unzip(src:"${unzipDir}/${config.zipName}", dest:"${unzipDir}", overwrite:true)
	//Ricordo che catalinaHome=${context.serviceDirectory}/${config.servicePackName}=${context.serviceDirectory}/apache-tomcat-7.0.23
	//move(file:"${unzipDir}/${config.servicePackName}", tofile:"${catalinaHome}")
	//chmod(dir:"${catalinaHome}/bin", perm:'+x', includes:"*.sh")
	
}


// Installazione sorgente.war
//if ( warUrl ) 
//{
//	new AntBuilder().sequential {
//		if ( warUrl.toLowerCase().startsWith("http") || warUrl.toLowerCase().startsWith("ftp"))
//		//In questo caso il war si trova su Internet e deve essere scaricato
//		{
//			echo(message:"Sto scaricando ${warUrl} con il nome ${applicationWar} ...")
//			ServiceUtils.getDownloadUtil().get("${warUrl}", "${applicationWar}", false)
//		}
//		else 
//		//Il sorgente e' presente nella cartella della ricetta del servizio
//		{
//			echo(message:"Sto copiando da ${context.serviceDirectory}/${warUrl} in ${applicationWar} ...")
//			copy(tofile: "${applicationWar}", file:"${context.serviceDirectory}/${warUrl}", overwrite:true)
//		}
//	}
//}


// Editing dei file di configurazione di tomcat (porte di ascolto e di spegnimento)
//File ctxConf = new File("${catalinaBase}/conf/Catalina/localhost/${contextPath}.xml")
//if (ctxConf.exists()) {
//	assert ctxConf.delete()
//} else {
//	new File(ctxConf.getParent()).mkdirs()
//}
//assert ctxConf.createNewFile()
//ctxConf.append("<Context docBase=\"${applicationWar}\" />")


//def serverXmlFile = new File("${catalinaBase}/conf/server.xml") 
//def serverXmlText = serverXmlFile.text
//portReplacementStr = "port=\"${config.port}\""
//ajpPortReplacementStr = "port=\"${config.ajpPort}\""
//shutdownPortReplacementStr = "port=\"${config.shutdownPort}\""

//serverXmlText = serverXmlText.replace("port=\"8080\"", portReplacementStr) 
//serverXmlText = serverXmlText.replace("port=\"8009\"", ajpPortReplacementStr) 
//serverXmlText = serverXmlText.replace("port=\"8005\"", shutdownPortReplacementStr) 
//serverXmlText = serverXmlText.replace('unpackWARs="true"', 'unpackWARs="false"')
//serverXmlFile.write(serverXmlText)


println "tomcat_install.groovy: Tomcat installazione terminata"

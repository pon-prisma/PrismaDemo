/*******************************************************************************
* Giuseppe G. - Reply S.p.A.
*******************************************************************************/
import org.cloudifysource.utilitydomain.context.ServiceContextFactory

def context = ServiceContextFactory.getServiceContext()
def config = new ConfigSlurper().parse(new File("${context.serviceDirectory}/tomcat-service.properties").toURL())
def instanceId = context.instanceId

println "tomcat_init.groovy: Initialize tomcat - Giuseppe..."


// Carica le configurazioni per Tomcat definite o nel properties (config) o nel service descriptor file o nel context (es applicationName)
//condizione ? se_condizione_e'_vera : se_condizione_e'_falsa
def catalinaHome = config.catalinaHome ?: "${context.serviceDirectory}/${config.servicePackName}"
def catalinaBase = config.catalinaBase ?: catalinaHome
def catalinaOpts = config.catalinaOpts ?: ""
def javaOpts = config.javaOpts ?: ""
//contextPath sara' applicationName, che sara' il nome con cui ho deployato la ricetta (es. apachetomcat)
def contextPath = config.contextPath ?: (context.applicationName != "default")? context.applicationName : "ROOT"

// Assegno le configurazioni al contesto di questa istanza
context.attributes.thisInstance["catalinaHome"] = "${catalinaHome}"
context.attributes.thisInstance["catalinaBase"] = "${catalinaBase}"
context.attributes.thisInstance["catalinaOpts"] = "${catalinaOpts}"
context.attributes.thisInstance["javaOpts"] = "${javaOpts}"
context.attributes.thisInstance["contextPath"] = "${contextPath}"
context.attributes.thisInstance["envVar"] = config.envVar

// Stampo a video le configurazioni del contesto di questa istanza
println "tomcat_init.groovy: tomcat(${instanceId}) catalinaHome is ${catalinaHome}"
println "tomcat_init.groovy: tomcat(${instanceId}) catalinaBase is ${catalinaBase}"
println "tomcat_init.groovy: tomcat(${instanceId}) catalinaOpts is ${catalinaOpts}"
println "tomcat_init.groovy: tomcat(${instanceId}) javaOpts is ${javaOpts}"
println "tomcat_init.groovy: tomcat(${instanceId}) contextPath is ${contextPath}"
println "tomcat_init.groovy: tomcat(${instanceId}) envVar is ${config.envVar}"



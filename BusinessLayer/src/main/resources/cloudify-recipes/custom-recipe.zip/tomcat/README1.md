Versione con scaling
Minimo 2 istanze, massimo 4, con scaling rule abbassata
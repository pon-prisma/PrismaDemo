#!/bin/bash -x

# args:
# $1 
# $2 
# $3 


# argomenti inseriti nella chiamata al file installOnUbuntu.sh  

serviceDirectory=$1
unzipDir=$2

downloadPath=$3
servicePackName=$4

sourcePath=$5
sourceName=$6

catalinaHome=$7			
contextPath=$8

port=$9
ajpPort=${10}
shutdownPort=${11}

userTomcat=${12}
passTomcat=${13}

mysqlJDBC=${14}
postgresJDBC=${15}

VM_ID=${16}
VM_IP=${17}

VM_HostName=${HOSTNAME}

echo "--Variabili VM_ID=${VM_ID}, VM_IP=${VM_IP}, VM_HostName=${VM_HostName}"



# Funzione errore di uscita
# args:
# $1 the error code of the last command (should be explicitly passed)
# $2 the message to print in case of an error
# 
# an error message is printed and the script exits with the provided error code
function funzione_errore_uscita {
	echo "$2 : error code: $1"
	exit ${1}
}

# Doppio pipe || = if the first command succeed the second will never be executed ovvero se export fallisce verrà chiamata "funzione_errore_uscita arg_1 arg_2"
export PATH=$PATH:/usr/sbin:/sbin:/usr/bin || funzione_errore_uscita $? "Failed on: export PATH=$PATH:/usr/sbin:/sbin"

# Check sy requiretty
echo "Check su requiretty..."
if sudo grep -q -E '[^!]requiretty' /etc/sudoers; then
    echo "Defaults:`whoami` !requiretty" | sudo tee /etc/sudoers.d/`whoami` >/dev/null
    sudo chmod 0440 /etc/sudoers.d/`whoami`
fi

# The existence of the usingAptGet file in the ext folder will later serve as a flag that "we" are on Ubuntu or Debian or Mint
echo "Using apt-get. Updating apt-get on one of the following : Ubuntu, Debian, Mint" > usingAptGet
sudo apt-get -y -q update || funzione_errore_uscita $? "Failed on: sudo apt-get -y update"

# Installo postgresql
echo "----------------Installazione JAVA 7 Oracle...." 

sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y purge openjdk* || funzione_errore_uscita $? "Failed on: purge openjdk*"
sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y install python-software-properties || funzione_errore_uscita $? "Failed on: install python-software-properties "
sudo add-apt-repository -y ppa:webupd8team/java || funzione_errore_uscita $? "Failed on: add-apt-repository ppa:webupd8team/java"
sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y update || funzione_errore_uscita $? "Failed on: apt-get update*"
echo debconf shared/accepted-oracle-license-v1-1 select true | sudo debconf-set-selections
echo debconf shared/accepted-oracle-license-v1-1 seen true | sudo debconf-set-selections
sudo apt-get -y install oracle-java7-installer || funzione_errore_uscita $? "Failed on: apt-get install oracle-java7-installer"

echo "Installazione java completata"

# Ora sto nella "context.serviceDirectory dove ci sono i file di tomcat.groovy"
echo "-----------------Installazione tomcat"
cd ${unzipDir} || funzione_errore_uscita $? "Failed on: cd ${unzipDir}"
wget $downloadPath || funzione_errore_uscita $? "Failed on: wget $downloadPath"
sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y install unzip
unzip $servicePackName.zip || funzione_errore_uscita $? "Failed on: unzip"
mv $servicePackName $serviceDirectory || funzione_errore_uscita $? "Failed on: move"
chmod 777 ${catalinaHome}/bin/*.sh
# Ricordo che catalinaHome = ${context.serviceDirectory}/${config.servicePackName}


# Ritorno nella serviceDirectory e copio i connettori JDBC in ${catalinaHome}/lib, supponendo che nella serviceDirectory i
# soli file .jar siano quelli dei driver...
echo "-----Download JDBC driver"
cd ${catalinaHome}/lib
wget $mysqlJDBC || funzione_errore_uscita $? "Failed on: wget $mysqlJDBC"
wget $postgresJDBC || funzione_errore_uscita $? "Failed on: wget $postgresJDBC"
echo "---------------- Fine installazione tomcat"

echo "-----------------Installazione sorgente.war"
#cd $serviceDirectory
#cp ${sourceName}.war ${catalinaHome}/webapps || funzione_errore_uscita $? "Failed on: copy helloworld.war"
cd ${catalinaHome}/webapps
wget $sourcePath
echo "-----------------Fine installazione sorgente.war"



echo "-----------------Configurazione tomcat ...."
echo "-----Configurazione utenti di management /conf/tomcat-users.xml"
sed -i -e '/<tomcat-users>/a <role rolename="manager-gui"/> \n <role rolename="admin-gui"/> \n <user name="'${userTomcat}'"   password="'${passTomcat}'" roles="admin-gui, manager-gui, manager-script, admin-script" />' ${catalinaHome}/conf/tomcat-users.xml

echo "-----Personalizzo conf/server.xml per le porte di ascolto"
sed -i -e "s/port=\"8080\"/port=\"${port}\"/" ${catalinaHome}/conf/server.xml
sed -i -e "s/port=\"8009\"/port=\"${ajpPort}\"/" ${catalinaHome}/conf/server.xml
sed -i -e "s/port=\"8005\"/port=\"${shutdownPort}\"/" ${catalinaHome}/conf/server.xml


echo "-----Personalizzo catalina.sh"
sed -i -e '99i JAVA_OPTS="-XX:MaxPermSize=160M -XX:NewSize=256M -Xms512M"\nJAVA_OPTS="$JAVA_OPTS -Xmx2048M -Xss512K"' ${catalinaHome}/bin/catalina.sh

echo "----Personalizzo catalina.sh per JAVA_HOME e CATALINA_HOME"
sed -i -e '/JAVA_OPTS="$JAVA_OPTS /a JAVA_HOME="/usr/lib/jvm/java-7-oracle"' ${catalinaHome}/bin/catalina.sh
sed -i -e '/JAVA_OPTS=\"$JAVA_OPTS /a 'CATALINA_HOME="${catalinaHome}"'' ${catalinaHome}/bin/catalina.sh

echo "-----------------Fine Configurazione tomcat ...."


#### --------------------------------Da rimuovere
echo "-----------------Installo Postgresql per scopi di test ...."
touch /etc/apt/sources.list.d/pgdg.list
echo deb http://apt.postgresql.org/pub/repos/apt/ precise-pgdg main | sudo tee /etc/apt/sources.list.d/pgdg.list
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
sudo DEBIAN_FRONTEND='noninteractive' apt-get -o Dpkg::Options::='--force-confnew' -q -y update || funzione_errore_uscita $? "Failed on: apt-get update*"
apt-get -y install postgresql-9.3

sed -i "s/#listen_addresses = 'localhost'/listen_addresses = '*'/g" /etc/postgresql/9.3/main/postgresql.conf
echo "host    all             all             0.0.0.0/0               trust" | tee -a /etc/postgresql/9.3/main/pg_hba.conf
echo "host    all             all             127.0.0.1/32               trust" | tee -a /etc/postgresql/9.3/main/pg_hba.conf
sudo service postgresql restart

mv $serviceDirectory/upDial.sql /opt

su - postgres << _EOF1_
psql -c "CREATE ROLE $userTomcat LOGIN;"
psql -c "ALTER ROLE $userTomcat WITH SUPERUSER;"
psql -c "ALTER ROLE $userTomcat WITH CREATEDB;"
psql -c "ALTER ROLE $userTomcat WITH CREATEROLE;"
psql -c "ALTER ROLE $userTomcat WITH PASSWORD '$passTomcat';"
psql -f /opt/upDial.sql
exit
_EOF1_


sudo service postgresql restart

#echo "----- Chiamata al web service per notificare avvenuta allocazione del servizio...."
#curl -X POST -H "Content-Type: application/json" -H "Accept: application/json" -d '{"action-type":"create_monitored_host","parameters":{"vmname":"${VM_HostName}","vmuuid":"${VM_ID}","vmip":"${VM_IP}"},"adapter-type":"zabbix"}' http://businesslayer02.cloud.reply.eu:8080/biz/rest/orchestrator/monitoring/create-monitored-host


echo "installOnUbuntu.sh: End"
import org.cloudifysource.utilitydomain.context.ServiceContextFactory

/**
 * This scripts implements the addNode custom command. This command enables a new back end server to add itself to the
 * load balancer, so that haproxy can distribute load to it.
 * 
 * To achieve this, the configuration file should be changed and the new configuration should be reloaded in a way that
 * is prompt and has minimal impact on the clients of the cluster.
 *  
 * @author lchen
 *
 */

println "haproxy_addNode.groovy: start"

context = ServiceContextFactory.getServiceContext()
config=new ConfigSlurper().parse(new File('haproxy-service.properties').toURL())


//args[0] = hostname
//args[1] = ipAddress
//args[2] = port (5672)
//nodeAddress = cloudify-agent-xxxxx 30.40.50.60:5672
def nodeAddress = args[0] + " " + args[1] + ":" + args[2]
//nodeAddressWebui = cloudify-agent-xxxxx 30.40.50.60:15672 - giuseppe
def nodeAddressWebui = args[0] + " " + args[1] + ":" + "1" + args[2]


def nodeAddressPlaceHolder = config.nodeAddressPlaceHolder
def serverLineTemplate = config.serverLineTemplate


//creo un file Object relativo al file /etc/haproxy_rabbitmq.conf
def configureFile = new File ("${config.configureFile}")
//copio il contenuto del file all'interno di una variabile sotto forma di stringa
def configureText = configureFile.text
//costruisco la stringa serverLineWebui inserendo nodeAddressWebui - giuseppe
def serverLineWebui = serverLineTemplate.replace(nodeAddressPlaceHolder, nodeAddressWebui)
println "haproxy_addNode.groovy: Adding the following line to ${config.configureFile}: ${serverLineWebui}"
//Quando viene chiamato addNode, il file postInstall e' già stato eseguito e quindi esiste gia' IP_proxy:mngport

def ipAddress
if (context.isLocalCloud()) {
		ipAddress =InetAddress.getLocalHost().getHostAddress()
	} else {
		ipAddress =System.getenv()["CLOUDIFY_AGENT_ENV_PRIVATE_IP"]
	}

def webuifrontEndMngPort = config.frontEndMngPort
def webuifrontEndIpAndPort = "${ipAddress}:${webuifrontEndMngPort}"
println "haproxy_addNode.groovy: ip e mngPort sono ${ipAddress}:${webuifrontEndMngPort}"
def substituteLine = "${webuifrontEndIpAndPort}" + System.getProperty("line.separator") + "${serverLineWebui}"
println "Sostituisco ${webuifrontEndIpAndPort} con ${substituteLine}"
def configureTextReplaced = configureText.replace(webuifrontEndIpAndPort, substituteLine)
println "haproxy_addNode.groovy: after configure webui, the configure text is: ${configureText}"
//copio la stringa nella variabile configureText all'interno del file configureFile
configureFile.text = configureTextReplaced



//popolo la sezione relativa al cluster (porta 5672)
//costruisco la stringa inserendo nodeAddress
def serverLine = serverLineTemplate.replace(nodeAddressPlaceHolder, nodeAddress)
println "haproxy_addNode.groovy: Adding the following line to ${config.configureFile}: ${serverLine}"
//appendo la stringa alla fine del file
configureFile.append(System.getProperty("line.separator") + serverLine)




println "haproxy_addNode.groovy: Reload configuration file ${config.configureFile} ... "
println "************* Reload configuration ************* "
new AntBuilder().sequential {
	echo(message:"haproxy_addNode.groovy: Chmodding +x ${context.serviceDirectory} ...")
	chmod(dir:"${context.serviceDirectory}", perm:"+x", includes:"*.sh")
	
	exec(executable:"${context.serviceDirectory}/reloadConfiguration.sh", osfamily:"unix") {
		arg(value:"${config.configureFile}")
		arg(value:"${config.pidFile}")
	}
}

println "haproxy_addNode.groovy: Reloaded configuration file ${config.configureFile}."

import org.cloudifysource.utilitydomain.context.ServiceContextFactory

/**
 *
 * This scripts configures haproxy.
 * @author lchen
 *
 */


// ----------- Definizione Funzioni

def configureStatisticPort (context, config, configureText) {
	def statisticPort = config.statisticPort
	println "Set the statistic port to ${statisticPort}"
	context.attributes.thisInstance["port"] = statisticPort
	return configureText.replace("8100","${statisticPort}")
}

def configureHttpFrontEnd (context, config, configureText) {
	def frontEndPort = config.frontEndPort
	context.attributes.thisInstance["frontEndPort"] = frontEndPort
	println "replace bind 0.0.0.0:8080 with bind 0.0.0.0:${frontEndPort}"
	return configureText.replace("bind 0.0.0.0:8080","bind 0.0.0.0:${frontEndPort}")
}

def configureTcpFrontEnd (context, config, configureText) {
	
	def ipAddress
	boolean isLocalCloud = context.isLocalCloud()
	
	if (isLocalCloud) {
		ipAddress =InetAddress.getLocalHost().getHostAddress()
	} else {
		ipAddress =System.getenv()["CLOUDIFY_AGENT_ENV_PRIVATE_IP"]
	}
	
	def frontEndPort = config.frontEndPort
	
	def frontEndIpAndPort = "${ipAddress}:${frontEndPort}"
	println "Set the front-end ip and port to ${frontEndIpAndPort}"
	return configureText.replace("<front-end IP and Port>", frontEndIpAndPort)
}

def configureWebuiFrontEnd (context, config, configureText) {
	
	def ipAddress
	boolean isLocalCloud = context.isLocalCloud()
	
	if (isLocalCloud) {
		ipAddress =InetAddress.getLocalHost().getHostAddress()
	} else {
		ipAddress =System.getenv()["CLOUDIFY_AGENT_ENV_PRIVATE_IP"]
	}
	
	def webuifrontEndMngPort = config.frontEndMngPort
	
	def webuifrontEndIpAndPort = "${ipAddress}:${webuifrontEndMngPort}"
	println "Set the webui front-end ip and port to ${webuifrontEndIpAndPort}"
	return configureText.replace("<webui front-end IP and MngPort>", webuifrontEndIpAndPort)
}

// ------- Fine Definizione Funzioni ------


println "haproxy_postInstall.groovy: About to configure haproxy ... "

context = ServiceContextFactory.getServiceContext()
config=new ConfigSlurper().parse(new File('haproxy-service.properties').toURL())
context.attributes.thisService["port"] = config.frontEndPort

//creo un file Object per la gestione del file di configurazione presente nella ricetta (nella serviceDirectory)
def configFileTemplate = new File ("${context.serviceDirectory}/${config.configFileTemplate}")
//copio il contenuto del file all'interno di in una variabile come testo
def configureText = configFileTemplate.text

configureText = configureStatisticPort(context, config, configureText)
configureText = configureHttpFrontEnd(context, config, configureText)
println "haproxy_postInstall.groovy: after configure http front end, the configure text is: ${configureText}" 
configureText = configureTcpFrontEnd(context, config, configureText)
println "haproxy_postInstall.groovy: after configure tcp front end, the configure text is: ${configureText}"
configureText = configureWebuiFrontEnd(context, config, configureText)
println "haproxy_postInstall.groovy: after configure webui front end, the configure text is: ${configureText}"

//creo un nuovo file Object al path del OS indicato da config.configureFile (cioe' /etc/haproxy_rabbitmq.conf)
def configureFile = new File ("${config.configureFile}")
//creo un nuovo file a quel path
configureFile.createNewFile()
//copio il contenuto della variabile configureText allinterno del nuovo file configureFile
configureFile.text = configureText

println "haproxy_postInstall.groovy: Finished the configuration of haproxy."
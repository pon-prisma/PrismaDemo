#!/bin/bash
#
# Installs the RabbitMQ server

echo "###### Installing Rabbit MQ Server on Ubuntu"

userAdmin=${1}
passAdmin=${2}
echo "####DA ROMUOVERE - User e Pass: ${userAdmin} e ${passAdmin}..."

# Install erlang
echo "Installazione di erlang..."
sudo apt-get -y install erlang-nox

# Install rabbit mq 
echo "Installazione di rabbitmq (versione 3.4.1-1)..."
wget http://www.rabbitmq.com/rabbitmq-signing-key-public.asc
apt-key add rabbitmq-signing-key-public.asc
echo "deb http://www.rabbitmq.com/debian/ testing main" > /etc/apt/sources.list.d/rabbitmq.list
apt-get update
apt-get install rabbitmq-server

# Adding RabbitMQ management 
#echo "Abilitazione di rabbitmq_management..."
#rabbitmq-plugins enable rabbitmq_management

#echo "Eseguo i comandi rabbitmqctl add_user, set_user_tags, set_permissions...."
#rabbitmqctl add_user $userAdmin $passAdmin
#rabbitmqctl set_user_tags $userAdmin administrator
#rabbitmqctl set_permissions -p / $userAdmin ".*" ".*" ".*"



# sudo /etc/init.d/rabbitmq-server stop (since the service gets started up on install)
# Infatti, nello script rabitmq_start, viene eseguito: /usr/sbin/rabbitmq-server -detached, che darebbe errore se ci fosse un rabbit-server gia' in running
sudo /etc/init.d/rabbitmq-server stop



echo "##### Finished installing Rabbit MQ Server on Ubuntu"

exit 0

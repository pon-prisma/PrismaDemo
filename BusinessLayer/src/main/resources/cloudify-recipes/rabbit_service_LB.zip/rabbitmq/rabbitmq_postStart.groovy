import org.cloudifysource.dsl.utils.ServiceUtils;
import org.cloudifysource.utilitydomain.context.ServiceContextFactory
import java.util.concurrent.TimeUnit

/**
 * 
 * Join the rabbitmq instance to a cluster. Determines whether a node should be a diskNode or not. 
 * The first two nodes will be set as disk node. The number of disk node can be configured in the properties file.
 * If use load balancer, the scripts add the new node to the load balancer configuration. 
 * @author lchen
 *
 */

//---DEFINIZIONE FUNZIONI
def joinCluster (context, diskNodeNames, isLocalCloud, istanza1, myInstanceID, userAdmin, passAdmin) 
{
	println "rabbitmq_postStart.groovy: About to join rabbitmq cluster... "
	
	if (isLocalCloud)
	{
		def fullNodeName = context.attributes.thisInstance['rabbitNodeName'] + "@" + context.attributes.thisInstance['hostname']
		println "rabbitmq_postStart.groovy: joining cluster on local cloud, the diskNodeNames of the cluster are ${diskNodeNames}"
		new AntBuilder().sequential {
			exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") {
				arg(value:"-n")
				arg(value:"${fullNodeName}")
				arg(value:"stop_app")
			}
			exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") {
				arg(value:"-n")
				arg(value:"${fullNodeName}")
				arg(value:"reset")
			}
			exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") {
				arg(line:"-n ${fullNodeName} cluster ${diskNodeNames}")
			}
			exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") {
				arg(value:"-n")
				arg(value:"${fullNodeName}")
				arg(value:"start_app")
			}
		}
		
	} 
	else 
	/* comandi per versione < 3.4.1
	{
		println "rabbitmq_postStart.groovy: joining cluster on cloud, the diskNodeNames of the cluster are ${diskNodeNames}"
		new AntBuilder().sequential 
		{
			exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix")
			{
				arg(value:"stop_app")
			}
			exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
			{
				arg(value:"reset")
			}
			exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
			{
				arg(line:"cluster ${diskNodeNames}")
			}
			exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
			{
				arg(value:"start_app")
			}
		}
		
	}
	*/
	//Di seguito i comandi per la versione >= 3.4.1
	{
		//Obsoleto - println "rabbitmq_postStart.groovy: joining cluster on cloud, the diskNodeNames of the cluster are ${diskNodeNames}"
		def permission = "-p / ${userAdmin} \".*\" \".*\" \".*\""

		if (myInstanceID == 1)
		{
			new AntBuilder().sequential 
			{
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(value:"cluster_status")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix")
				{
					arg(value:"stop_app")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(value:"reset")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(value:"start_app")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(value:"cluster_status")
				}
				exec(executable:"/usr/sbin/rabbitmq-plugins", osfamily:"unix") 
				{
					arg(line:"enable rabbitmq_management")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(line:"add_user ${userAdmin} ${passAdmin}")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(line:"set_user_tags ${userAdmin} administrator")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(line:"set_permissions ${permission}")
				}
			}
		}
		else
		{
			new AntBuilder().sequential 
			{
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(value:"cluster_status")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix")
				{
					arg(value:"stop_app")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(value:"reset")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(line:"join_cluster ${istanza1}")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(value:"start_app")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(value:"cluster_status")
				}
				exec(executable:"/usr/sbin/rabbitmq-plugins", osfamily:"unix") 
				{
					arg(line:"enable rabbitmq_management")
				}				 
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(line:"add_user ${userAdmin} ${passAdmin}")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(line:"set_user_tags ${userAdmin} administrator")
				}
				exec(executable:"/usr/sbin/rabbitmqctl", osfamily:"unix") 
				{
					arg(line:"set_permissions ${permission}")
				}
			}

		}
		
	}

	println "rabbitmq_postStart.groovy: End of join rabbitmq cluster."
}

def addToLoadBalancer (config, context, isLocalCloud, rabbitNodeName, hostname)
{
	def loadBalancerName = config.loadBalancerName
	println "rabbitmq_postStart.groovy: Use load balancer ${loadBalancerName}."
	def name
	if (isLocalCloud) {
		//rabbitNodeName e' rabbit nel caso di NonLocalCloud
		name = rabbitNodeName
	} else {
		//hostname e' del tipo cloudify-agent-rabbit-...
		name = hostname
	}
	
	def ipAddress = context.attributes.thisInstance["ipAddress"]
	def port = context.attributes.thisInstance["port"]
	def nodeAddress = name + " " + ipAddress + ":" + port
	//nodeAddress = cloudify-agent-rabbit-... 30.40.50.60:5672
	
	println "rabbitmq_postStart.groovy: About to add ${nodeAddress} to ${loadBalancerName} by invoking the addNode command with parameters ${name} ${ipAddress} ${port} ... "
	
	def loadBalancingService = context.waitForService(loadBalancerName, 180, TimeUnit.SECONDS)
	loadBalancingService.invoke("addNode", name as String, ipAddress as String, port as String)
	
	println "rabbitmq_postStart.groovy: Added ${nodeAddress} to ${loadBalancerName} by invoking the addNode command with parameters ${name} ${ipAddress} ${port}."
}

//---Fine DEFINIZIONE FUNZIONI

println "rabbitmq_postStart.groovy: Start of postStart processing ... "

config = new ConfigSlurper().parse(new File('rabbitmq-service.properties').toURL())
context = ServiceContextFactory.getServiceContext()

def myInstanceID=context.instanceId
def adminUser = config.userAdmin
def adminPass = config.passAdmin


boolean isDisk = false
boolean isLocalCloud = context.isLocalCloud()
def hostname = context.attributes.thisInstance["hostname"]
def rabbitNodeName

if (isLocalCloud)
{
	rabbitNodeName = context.attributes.thisInstance["rabbitNodeName"]
} 
else 
{
	rabbitNodeName = "rabbit"
}


// This flag is used to coordinate instance start sequence to form the cluster correctly ... Aggiunto da Giuseppe
if (myInstanceID != 1)
{
	//Istanze 2,3,4....
	println "rabbitmq_postStart.groovy: My Instance ID is: ${myInstanceID}. firstInstanceReady: ${context.attributes.thisService['firstInstanceReady']}."
	while (!context.attributes.thisService["firstInstanceReady"]){
		println "rabbitmq_postStart.groovy: Wait for the first instance to become ready ... "
		Thread.sleep(5000)
	}
	println "firstInstanceReady e' ora: ${context.attributes.thisService['firstInstanceReady']}"
}

//istanza1 - e' il nome dell'istanza 1 che verrà usata come base per creare il cluster. In pratica,
//tutti i successivi nodi vengono joined a questa istanza
def istanza1 
if (myInstanceID == 1)
{	
	context.attributes.thisService["fullNodeNameIstanza1"] = "${rabbitNodeName}@${hostname}"
	istanza1 = context.attributes.thisService["fullNodeNameIstanza1"]
	println "rabbitmq_postStart.groovy: My Instance ID is: ${myInstanceID} e fullNodeNameIstanza1 is ${istanza1}"
}
else
{
	istanza1 = context.attributes.thisService["fullNodeNameIstanza1"]
	println "rabbitmq_postStart.groovy: My Instance ID is: ${myInstanceID} e fullNodeNameIstanza1 is ${istanza1}"
}


def rabbitmqInstances = context.attributes.rabbitmq.instances;
int diskNodesCount = 0

StringBuilder diskNodeNamesBuilder = new StringBuilder()

for (i in rabbitmqInstances)
{
		if (i.isDisk && i.instanceId != myInstanceID){
		diskNodesCount ++
		if (isLocalCloud) {
			diskNodeNamesBuilder.append("${i.rabbitNodeName}@${i.hostname} ")
		} else {
			diskNodeNamesBuilder.append("rabbit@${i.hostname} ")
		}
	}
}

def numberOfConfiguredDiskNodes

if (config.numberOfDiskNodes != null){
	println "Siamo in config.numberOfDiskNodes != null..."
	numberOfConfiguredDiskNodes = config.numberOfDiskNodes
} else {
	println "Siamo in config.numberOfDiskNodes == null..."
	numberOfConfiguredDiskNodes = 2
}

println "Disk_Nodes_Count: " + diskNodesCount
println "numberOfConfiguredDiskNodes: " + numberOfConfiguredDiskNodes

if (diskNodesCount < numberOfConfiguredDiskNodes){
	isDisk = true
}

println "Set isDisk for current node to: " + isDisk
context.attributes.thisInstance["isDisk"] = isDisk

if (isDisk)
{
	diskNodeNamesBuilder.append("${rabbitNodeName}@${hostname} ")
}

def diskNodeNames = diskNodeNamesBuilder.toString().trim()


//Chiamo la funzione joinCluster
joinCluster (context, diskNodeNames, isLocalCloud, istanza1, myInstanceID, adminUser, adminPass)

//Verifico se e' stato richiesto il load balancer
boolean useLoadBalancer = config.useLoadBalancer
if (useLoadBalancer)
{
	addToLoadBalancer(config, context, isLocalCloud, rabbitNodeName, hostname)
}


//Dopo le funzioni joincluster e load balancing, posso dire che l'istanza 1 e' ready
if (myInstanceID == 1)
{
	println "rabbitmq_postStart.groovy: First instance is ready."
	context.attributes.thisService["firstInstanceReady"] = true
}



println "rabbitmq_postStart.groovy: End of postStart processing."

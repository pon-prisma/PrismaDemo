application 
{
	name="rabbit"
	
	service {
		name = "haproxy"
	}

	service {
		name = "rabbitmq"
		dependsOn = ["haproxy"]
		
	}
}